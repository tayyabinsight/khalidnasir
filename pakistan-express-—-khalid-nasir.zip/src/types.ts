export interface RouteItem {
  id: string;
  from: string;
  to: string;
  via: string[];
  duration: string;
  distance: string;
  departureTime: string;
  arrivalTime: string;
  farePKR: number;
  busType: 'Royal Executive' | 'VIP Sleeper' | 'Business Plus';
  availableSeats: number;
  featured?: boolean;
}

export interface CityNode {
  id: string;
  name: string;
  urduName?: string;
  x: number; // percentage on map
  y: number; // percentage on map
  isMajor: boolean;
  terminals: number;
  dailyDepartures: number;
}

export interface MapConnection {
  from: string;
  to: string;
  active: boolean;
}

export interface BusHotspot {
  id: string;
  title: string;
  subtitle: string;
  x: number; // percentage
  y: number; // percentage
  description: string;
  category: 'comfort' | 'technology' | 'safety' | 'luxury';
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  city: string;
  route: string;
  avatar: string;
  rating: number;
  quote: string;
  date: string;
}

export interface Seat {
  id: string;
  number: string;
  row: number;
  col: number; // 1, 2, 3 (for 1+2 layout)
  type: 'single' | 'double-window' | 'double-aisle';
  isBooked: boolean;
  gender?: 'male' | 'female';
  price: number;
}

export interface BookingState {
  from: string;
  to: string;
  date: string;
  passengers: number;
  busType: string;
  selectedSeats: string[];
  passengerName: string;
  passengerPhone: string;
  passengerCNIC: string;
  paymentMethod: 'JazzCash' | 'Easypaisa' | '1Link' | 'Cash';
}
