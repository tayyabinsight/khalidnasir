import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'motion/react';
import { InitialLoader } from './components/InitialLoader';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { JourneyStartsSection } from './components/JourneyStartsSection';
import { PakistanMapSection } from './components/PakistanMapSection';
import { FeaturesSection } from './components/FeaturesSection';
import { LiveJourneyVisual } from './components/LiveJourneyVisual';
import { BusShowcaseSection } from './components/BusShowcaseSection';
import { RoutesSection } from './components/RoutesSection';
import { BookingExperienceDemo } from './components/BookingExperienceDemo';
import { TestimonialsSection } from './components/TestimonialsSection';
import { BrandStatementSection } from './components/BrandStatementSection';
import { FinalCTASection } from './components/FinalCTASection';
import { Footer } from './components/Footer';
import { SeatBookingModal } from './components/SeatBookingModal';
import { TrackBookingModal } from './components/TrackBookingModal';
import { WhatsAppDemoModal } from './components/WhatsAppDemoModal';
import { RouteItem } from './types';

export default function App() {
  const [loading, setLoading] = useState(true);
  const [darkMode, setDarkMode] = useState(true);
  
  // Modals state
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [isTrackOpen, setIsTrackOpen] = useState(false);
  const [isWhatsAppOpen, setIsWhatsAppOpen] = useState(false);

  // Booking parameters passed to modal
  const [bookingParams, setBookingParams] = useState<{
    from: string;
    to: string;
    date: string;
    passengers: number;
  }>({
    from: 'Karachi',
    to: 'Rawalpindi',
    date: 'Today, Aug 18',
    passengers: 1,
  });

  const [selectedRouteForBooking, setSelectedRouteForBooking] = useState<RouteItem | null>(null);

  // Dark / Light Mode HTML class sync
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
    }
  }, [darkMode]);

  const handleOpenBookingWithParams = (params: { from: string; to: string; date: string; passengers: number }) => {
    setBookingParams(params);
    setSelectedRouteForBooking(null);
    setIsBookingOpen(true);
  };

  const handleSelectRoute = (route: RouteItem) => {
    setSelectedRouteForBooking(route);
    setBookingParams({
      from: route.from,
      to: route.to,
      date: 'Today, Aug 18',
      passengers: 1,
    });
    setIsBookingOpen(true);
  };

  const handleSelectCityRoute = (cityName: string) => {
    setBookingParams({
      from: cityName,
      to: cityName === 'Rawalpindi' ? 'Karachi' : 'Rawalpindi',
      date: 'Today, Aug 18',
      passengers: 1,
    });
    setSelectedRouteForBooking(null);
    setIsBookingOpen(true);
  };

  const handleExploreRoutes = () => {
    const routesElem = document.getElementById('routes');
    if (routesElem) {
      routesElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className={`min-h-screen bg-[#030604] text-white selection:bg-emerald-500 selection:text-black font-sans transition-colors duration-300 ${darkMode ? 'dark' : 'light'}`}>
      
      {/* 1. Initial Loading Screen */}
      <AnimatePresence>
        {loading && <InitialLoader onComplete={() => setLoading(false)} />}
      </AnimatePresence>

      {/* 2. Floating Navbar */}
      <Navbar
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        onOpenBooking={() => setIsBookingOpen(true)}
        onOpenTrack={() => setIsTrackOpen(true)}
      />

      {/* 3. Main Landing Page Sections */}
      <main className="relative">
        
        {/* Section 2-6: Hero Section with Cinematic Bus Highway & Floating Booking Card */}
        <HeroSection
          onOpenBookingWithParams={handleOpenBookingWithParams}
          onExploreRoutes={handleExploreRoutes}
        />

        {/* Section 8: "The Journey Starts Here" */}
        <JourneyStartsSection onOpenBooking={() => setIsBookingOpen(true)} />

        {/* Section 9: Pakistan Map Animation (One Network. Countless Journeys) */}
        <PakistanMapSection onSelectCityRoute={handleSelectCityRoute} />

        {/* Section 10: Features Section (Easy Booking, Choose Seat, Confidence, Payments) */}
        <FeaturesSection onOpenBooking={() => setIsBookingOpen(true)} />

        {/* Section 11: Live Journey Visual (On The Road Telemetry) */}
        <LiveJourneyVisual />

        {/* Section 12: Bus Showcase with Interactive Hotspots (Exterior & VIP Cabin) */}
        <BusShowcaseSection />

        {/* Section 13: Explore The Routes */}
        <RoutesSection onSelectRoute={handleSelectRoute} />

        {/* Section 14: Interactive Booking Experience Preview */}
        <BookingExperienceDemo />

        {/* Section 15: Testimonials Section */}
        <TestimonialsSection />

        {/* Section 16: Brand Statement (We Don't Just Move Buses. We Move People. We Connect Journeys.) */}
        <BrandStatementSection />

        {/* Section 17: Final Booking CTA */}
        <FinalCTASection
          onOpenBooking={() => setIsBookingOpen(true)}
          onOpenWhatsApp={() => setIsWhatsAppOpen(true)}
        />
      </main>

      {/* 4. Footer */}
      <Footer
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        onOpenBooking={() => setIsBookingOpen(true)}
        onOpenTrack={() => setIsTrackOpen(true)}
        onOpenWhatsApp={() => setIsWhatsAppOpen(true)}
      />

      {/* 5. Interactive Modals */}
      <AnimatePresence>
        {isBookingOpen && (
          <SeatBookingModal
            isOpen={isBookingOpen}
            onClose={() => setIsBookingOpen(false)}
            initialParams={bookingParams}
            initialRoute={selectedRouteForBooking}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isTrackOpen && (
          <TrackBookingModal
            isOpen={isTrackOpen}
            onClose={() => setIsTrackOpen(false)}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isWhatsAppOpen && (
          <WhatsAppDemoModal
            isOpen={isWhatsAppOpen}
            onClose={() => setIsWhatsAppOpen(false)}
          />
        )}
      </AnimatePresence>

    </div>
  );
}
