import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Bus, MapPin, Clock, ArrowRight, Sparkles, Navigation, Search, Filter } from 'lucide-react';
import { POPULAR_ROUTES } from '../data/mockData';
import { RouteItem } from '../types';

interface RoutesSectionProps {
  onSelectRoute: (route: RouteItem) => void;
}

export const RoutesSection: React.FC<RoutesSectionProps> = ({ onSelectRoute }) => {
  const [filterOrigin, setFilterOrigin] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const origins = ['All', 'Karachi', 'Hyderabad', 'Multan', 'Faisalabad', 'Rawalpindi'];

  const filteredRoutes = POPULAR_ROUTES.filter((r) => {
    const matchesOrigin = filterOrigin === 'All' || r.from.toLowerCase() === filterOrigin.toLowerCase();
    const matchesSearch =
      r.from.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.to.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.busType.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesOrigin && matchesSearch;
  });

  return (
    <section id="routes" className="relative py-24 bg-[#030604] text-white overflow-hidden border-t border-emerald-950/40">
      {/* Background ambient lighting */}
      <div className="absolute top-1/3 left-1/4 w-[50vw] h-[50vh] bg-emerald-950/15 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-950/70 border border-emerald-500/30 text-emerald-400 text-xs font-mono-tech uppercase tracking-widest mb-4"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>SCHEDULES & MOTORWAY EXPRESS CORRIDORS</span>
            </motion.div>

            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white uppercase font-heading"
            >
              Explore The <br className="sm:hidden" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-emerald-300 to-white">
                Routes
              </span>
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="mt-3 text-sm sm:text-base text-gray-300 max-w-xl"
            >
              Discover premier daily departures connecting Punjab, Sindh, KPK, and federal capital terminals.
            </motion.p>
          </div>

          {/* Quick Filters */}
          <div className="mt-6 md:mt-0 flex flex-wrap items-center gap-2">
            {origins.map((origin) => (
              <button
                key={origin}
                onClick={() => setFilterOrigin(origin)}
                className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition-all duration-200 ${
                  filterOrigin === origin
                    ? 'bg-emerald-500 text-black shadow-[0_0_15px_rgba(16,185,129,0.5)]'
                    : 'bg-black/60 text-gray-300 hover:text-white border border-white/10 hover:border-emerald-500/40'
                }`}
              >
                {origin === 'All' ? 'All Routes' : `From ${origin}`}
              </button>
            ))}
          </div>
        </div>

        {/* Large Horizontal Route Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredRoutes.map((route, idx) => (
            <motion.div
              key={route.id}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.6 }}
              className="glass-panel-glow rounded-3xl p-6 border border-emerald-500/30 relative overflow-hidden flex flex-col justify-between group hover:border-emerald-400 transition-all duration-300 shadow-xl"
            >
              {/* Card Header: Fleet Type & Availability Badge */}
              <div className="flex items-center justify-between pb-4 border-b border-emerald-950/70">
                <span className="px-3 py-1 rounded-full text-[10px] font-mono-tech uppercase tracking-wider bg-emerald-950 border border-emerald-500/40 text-emerald-300 font-bold">
                  {route.busType}
                </span>

                <span className="text-[11px] font-mono-tech text-gray-400 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  {route.availableSeats} Seats Left
                </span>
              </div>

              {/* Origin & Destination Display */}
              <div className="mt-5">
                <div className="flex items-center justify-between gap-4">
                  <div className="flex-1">
                    <div className="text-[10px] uppercase text-gray-400 font-mono-tech">DEPARTURE</div>
                    <div className="text-xl font-extrabold text-white uppercase tracking-wide font-heading">
                      {route.from}
                    </div>
                    <div className="text-xs text-emerald-400 font-mono-tech mt-0.5">
                      {route.departureTime}
                    </div>
                  </div>

                  {/* Route line & bus icon with animated hover pulse */}
                  <div className="flex flex-col items-center px-2">
                    <div className="text-[9px] font-mono-tech text-gray-400 mb-1">{route.duration}</div>
                    <div className="relative w-16 sm:w-20 h-[2px] bg-emerald-950 flex items-center justify-center">
                      <div className="w-full h-full bg-emerald-500/50 group-hover:bg-emerald-400 transition-colors" />
                      <div className="absolute p-1 rounded-full bg-black border border-emerald-400 group-hover:scale-125 transition-transform">
                        <Bus className="w-3 h-3 text-emerald-400" />
                      </div>
                    </div>
                    <div className="text-[9px] font-mono-tech text-emerald-400/80 mt-1">{route.distance}</div>
                  </div>

                  <div className="flex-1 text-right">
                    <div className="text-[10px] uppercase text-gray-400 font-mono-tech">ARRIVAL</div>
                    <div className="text-xl font-extrabold text-white uppercase tracking-wide font-heading">
                      {route.to}
                    </div>
                    <div className="text-xs text-gray-300 font-mono-tech mt-0.5">
                      {route.arrivalTime}
                    </div>
                  </div>
                </div>

                {/* Via Key Interchanges */}
                <div className="mt-4 p-2.5 rounded-xl bg-black/40 border border-white/5 text-[11px] text-gray-400 flex items-center gap-1.5 overflow-hidden">
                  <span className="text-emerald-400 font-bold uppercase text-[9px] shrink-0">VIA:</span>
                  <span className="truncate">{route.via.join(' • ')}</span>
                </div>
              </div>

              {/* Fare & Instant Booking CTA */}
              <div className="mt-6 pt-4 border-t border-emerald-950/70 flex items-center justify-between">
                <div>
                  <div className="text-[10px] text-gray-400 uppercase font-mono-tech">ONE-WAY FARE</div>
                  <div className="text-xl font-extrabold text-emerald-400 font-mono-tech">
                    PKR {route.farePKR.toLocaleString()}
                  </div>
                </div>

                <button
                  onClick={() => onSelectRoute(route)}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-400 text-black font-extrabold text-xs uppercase tracking-wider shadow-[0_0_15px_rgba(16,185,129,0.3)] group-hover:shadow-[0_0_25px_rgba(16,185,129,0.6)] flex items-center gap-1.5 transition-all group-hover:scale-105"
                >
                  <span>Select</span>
                  <ArrowRight className="w-3.5 h-3.5 text-black" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
};
