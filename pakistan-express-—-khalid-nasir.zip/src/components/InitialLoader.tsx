import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bus, Sparkles } from 'lucide-react';

interface InitialLoaderProps {
  onComplete: () => void;
}

export const InitialLoader: React.FC<InitialLoaderProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(onComplete, 400);
          return 100;
        }
        return prev + 4;
      });
    }, 40);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <motion.div
      id="initial-loader"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, y: -20, transition: { duration: 0.8, ease: [0.22, 1, 0.36, 1] } }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#030604] text-white select-none overflow-hidden"
    >
      {/* Background cinematic radial ambient glow */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.15)_0%,rgba(3,6,4,0.95)_70%)]" />

      {/* Subtle grid pattern */}
      <div className="absolute inset-0 opacity-10 bg-[linear-gradient(to_right,#10b981_1px,transparent_1px),linear-gradient(to_bottom,#10b981_1px,transparent_1px)] bg-[size:4rem_4rem]" />

      <div className="relative z-10 flex flex-col items-center max-w-md px-6 text-center">
        {/* Animated Crest Icon */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="relative mb-6"
        >
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-black border border-emerald-500/40 flex items-center justify-center shadow-[0_0_40px_rgba(16,185,129,0.3)]">
            <Bus className="w-10 h-10 text-emerald-400" />
          </div>
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
            className="absolute -inset-2 border border-dashed border-emerald-500/30 rounded-3xl"
          />
        </motion.div>

        {/* Brand Title */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.6 }}
        >
          <h1 className="text-3xl sm:text-4xl font-bold tracking-[0.25em] text-white font-heading uppercase">
            Pakistan Express
          </h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="mt-2 text-xs sm:text-sm tracking-[0.4em] uppercase text-emerald-400 font-semibold flex items-center justify-center gap-2"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            Khalid Nasir
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
          </motion.p>
        </motion.div>

        {/* Animated Road Track and Travelling Bus */}
        <div className="w-full mt-10 relative">
          <div className="h-[2px] w-full bg-emerald-950/80 relative rounded-full overflow-hidden">
            {/* Progress line */}
            <motion.div
              className="h-full bg-gradient-to-r from-emerald-600 via-emerald-400 to-white shadow-[0_0_15px_#10b981]"
              style={{ width: `${progress}%` }}
            />
          </div>

          {/* Miniature traveling bus icon on track */}
          <motion.div
            className="absolute -top-3.5 -translate-x-1/2 text-emerald-400"
            style={{ left: `${Math.min(progress, 98)}%` }}
            transition={{ duration: 0.1 }}
          >
            <div className="relative">
              <Bus className="w-5 h-5 text-emerald-300 drop-shadow-[0_0_8px_#10b981]" />
              <div className="absolute -bottom-1 -left-1 w-2 h-1 bg-emerald-400 blur-[2px] rounded-full animate-pulse" />
            </div>
          </motion.div>

          <div className="mt-4 flex justify-between items-center text-[11px] font-mono-tech text-gray-400 tracking-wider">
            <span className="text-emerald-500/80">INITIALIZING FLEET SYSTEM</span>
            <span className="text-emerald-400 font-bold">{progress}%</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
