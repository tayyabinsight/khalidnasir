import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Shield, Compass } from 'lucide-react';

export const BrandStatementSection: React.FC = () => {
  return (
    <section id="brand-statement" className="relative min-h-[90vh] py-28 bg-[#050505] text-white flex items-center justify-center overflow-hidden border-t border-white/10 select-none">
      
      {/* Background Highway Night Lights Stream & Immersive Grid */}
      <div className="absolute inset-0 immersive-grid-pattern opacity-40 pointer-events-none" />

      <div className="absolute inset-0 pointer-events-none opacity-25">
        <div className="absolute top-1/2 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_30px_#10b981]" />
        
        {/* Animated Light Trails */}
        <motion.div
          animate={{ x: [-1000, 1500] }}
          transition={{ duration: 6, repeat: Infinity, ease: 'linear' }}
          className="absolute top-[48%] w-96 h-1 bg-gradient-to-r from-transparent via-emerald-300 to-white blur-[2px]"
        />
        <motion.div
          animate={{ x: [1500, -1000] }}
          transition={{ duration: 7.5, repeat: Infinity, ease: 'linear' }}
          className="absolute top-[52%] w-80 h-1 bg-gradient-to-r from-emerald-600 to-transparent blur-[2px]"
        />
      </div>

      {/* Atmospheric radial emerald nebula */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[70vw] h-[70vh] bg-emerald-950/25 rounded-full blur-[180px] pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center flex flex-col items-center">
        
        {/* Khalid Nasir Crest */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="inline-flex items-center gap-2 px-4 py-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 text-xs font-mono-tech tracking-widest uppercase mb-12 backdrop-blur-md shadow-[0_0_25px_rgba(16,185,129,0.2)]"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>PHILOSOPHY OF KHALID NASIR</span>
        </motion.div>

        {/* The 3 Staggered Powerful Typographic Statements */}
        <div className="space-y-6 sm:space-y-8 max-w-5xl">
          
          {/* Statement 1: WE DON'T JUST MOVE BUSES. */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.9, delay: 0.1 }}
          >
            <h2 className="text-3xl sm:text-5xl md:text-7xl font-extrabold tracking-tight text-white/50 uppercase font-heading">
              We Don't Just Move Buses.
            </h2>
          </motion.div>

          {/* Statement 2: WE MOVE PEOPLE. */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 40 }}
            whileInView={{ opacity: 1, scale: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.9, delay: 0.4 }}
          >
            <h2 className="text-4xl sm:text-6xl md:text-8xl font-black tracking-tight text-white uppercase font-heading">
              We Move <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-emerald-200 to-white drop-shadow-[0_0_35px_rgba(16,185,129,0.4)]">People.</span>
            </h2>
          </motion.div>

          {/* Statement 3: WE CONNECT JOURNEYS. */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.9, delay: 0.7 }}
          >
            <h2 className="text-3xl sm:text-5xl md:text-7xl font-extrabold tracking-tight text-emerald-400 uppercase font-heading drop-shadow-[0_0_25px_rgba(16,185,129,0.3)]">
              We Connect Journeys.
            </h2>
          </motion.div>

        </div>

        {/* Decorative Divider */}
        <motion.div
          initial={{ width: 0, opacity: 0 }}
          whileInView={{ width: '12rem', opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 1 }}
          className="mt-12 h-[1px] bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_15px_#10b981]"
        />

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 1.1 }}
          className="mt-6 text-sm sm:text-base text-emerald-100/70 max-w-xl leading-relaxed font-light"
        >
          Every departure is a commitment to dignity, safety, and seamless movement across the heart of Pakistan.
        </motion.p>

      </div>
    </section>
  );
};
