import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  MapPin, 
  Calendar, 
  Bus, 
  Armchair, 
  Check, 
  ArrowRight, 
  ArrowLeft, 
  ShieldCheck, 
  QrCode, 
  CreditCard,
  User,
  Phone,
  Ticket
} from 'lucide-react';
import { SEAT_MAP, POPULAR_ROUTES } from '../data/mockData';
import { Seat } from '../types';

export const BookingExperienceDemo: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedRoute, setSelectedRoute] = useState(POPULAR_ROUTES[0]);
  const [selectedBusClass, setSelectedBusClass] = useState<'Royal Executive' | 'VIP Sleeper'>('Royal Executive');
  const [selectedSeats, setSelectedSeats] = useState<string[]>(['2A']);
  const [passengerName, setPassengerName] = useState('Hamza Ali Khan');
  const [passengerPhone, setPassengerPhone] = useState('0300-1234567');
  const [paymentMethod, setPaymentMethod] = useState<'JazzCash' | 'Easypaisa' | '1Link' | 'Cash'>('JazzCash');

  const toggleSeat = (seat: Seat) => {
    if (seat.isBooked) return;
    if (selectedSeats.includes(seat.number)) {
      setSelectedSeats(selectedSeats.filter((s) => s !== seat.number));
    } else {
      if (selectedSeats.length < 4) {
        setSelectedSeats([...selectedSeats, seat.number]);
      }
    }
  };

  const calculateTotal = () => {
    const baseFare = selectedBusClass === 'VIP Sleeper' ? 7500 : 6200;
    return baseFare * Math.max(selectedSeats.length, 1);
  };

  return (
    <section id="experience" className="relative py-24 bg-[#020503] text-white overflow-hidden border-t border-emerald-950/40">
      {/* Glow */}
      <div className="absolute top-1/2 right-1/4 w-[50vw] h-[50vh] bg-emerald-950/20 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-950/70 border border-emerald-500/30 text-emerald-400 text-xs font-mono-tech uppercase tracking-widest mb-4"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>SEAMLESS DIGITAL PASSENGER PORTAL</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white uppercase font-heading"
          >
            Interactive Booking <br className="sm:hidden" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-emerald-300 to-white">
              Experience
            </span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="mt-4 text-sm sm:text-base text-gray-300"
          >
            Test our 4-step instant reservation workflow. From personalized seat selection to instant biometric boarding passes.
          </motion.p>
        </div>

        {/* The Interactive Demo Experience Card */}
        <div className="max-w-4xl mx-auto glass-panel-glow rounded-3xl p-6 sm:p-10 border border-emerald-500/40 shadow-2xl relative">
          
          {/* Step Progress Tracker */}
          <div className="grid grid-cols-4 gap-2 sm:gap-4 pb-8 border-b border-emerald-950/80">
            {[
              { num: 1, title: 'Route', desc: 'Choose Destination' },
              { num: 2, title: 'Fleet', desc: 'Select Travel Class' },
              { num: 3, title: 'Seats', desc: 'Pick 1+2 Recliners' },
              { num: 4, title: 'Pass', desc: 'E-Ticket & QR' },
            ].map((step) => {
              const isActive = currentStep === step.num;
              const isDone = currentStep > step.num;
              return (
                <button
                  key={step.num}
                  onClick={() => setCurrentStep(step.num)}
                  className={`text-left p-2.5 sm:p-3 rounded-2xl border transition-all ${
                    isActive
                      ? 'bg-emerald-500/20 border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.3)]'
                      : isDone
                      ? 'bg-emerald-950/40 border-emerald-600/40 text-gray-300'
                      : 'bg-black/40 border-white/5 text-gray-400 opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span
                      className={`w-5 h-5 rounded-full text-[11px] font-mono-tech flex items-center justify-center font-bold ${
                        isDone
                          ? 'bg-emerald-400 text-black'
                          : isActive
                          ? 'bg-white text-black'
                          : 'bg-neutral-800 text-gray-400'
                      }`}
                    >
                      {isDone ? <Check className="w-3 h-3" /> : step.num}
                    </span>
                    <span className="text-xs font-bold text-white uppercase hidden sm:inline">
                      {step.title}
                    </span>
                  </div>
                  <div className="text-[10px] text-gray-400 mt-1 truncate hidden md:block">
                    {step.desc}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Dynamic Step Content with Smooth Animation */}
          <div className="py-8 min-h-[360px]">
            <AnimatePresence mode="wait">
              
              {/* STEP 01: CHOOSE ROUTE */}
              {currentStep === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  <div>
                    <h3 className="text-xl font-bold text-white font-heading">
                      STEP 01: Choose Your Journey Route
                    </h3>
                    <p className="text-xs text-gray-400 mt-1">
                      Select departure terminal and destination corridor.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {POPULAR_ROUTES.slice(0, 4).map((route) => (
                      <div
                        key={route.id}
                        onClick={() => setSelectedRoute(route)}
                        className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                          selectedRoute.id === route.id
                            ? 'bg-emerald-950/60 border-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.3)]'
                            : 'bg-black/50 border-white/10 hover:border-emerald-500/30'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-extrabold text-white font-heading">
                            {route.from} → {route.to}
                          </span>
                          <span className="text-xs font-bold text-emerald-400 font-mono-tech">
                            PKR {route.farePKR.toLocaleString()}
                          </span>
                        </div>
                        <div className="text-xs text-gray-400 mt-1">
                          Departure: {route.departureTime} • {route.duration}
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* STEP 02: CHOOSE BUS CLASS */}
              {currentStep === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  <div>
                    <h3 className="text-xl font-bold text-white font-heading">
                      STEP 02: Select Fleet Class
                    </h3>
                    <p className="text-xs text-gray-400 mt-1">
                      Choose between our flagship Royal Executive and VIP Sleeper coaches.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {/* Royal Executive */}
                    <div
                      onClick={() => setSelectedBusClass('Royal Executive')}
                      className={`p-6 rounded-3xl border cursor-pointer transition-all ${
                        selectedBusClass === 'Royal Executive'
                          ? 'bg-emerald-950/60 border-emerald-400 shadow-[0_0_25px_rgba(16,185,129,0.4)]'
                          : 'bg-black/50 border-white/10'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-extrabold text-white">Royal Executive</span>
                        <span className="text-sm font-bold text-emerald-400 font-mono-tech">PKR 6,200</span>
                      </div>
                      <p className="text-xs text-gray-400 mt-2">
                        1+2 Italian Leather Recliners with 160° tilt, individual Android infotainment screens, Starlink Wi-Fi, and hot refreshments.
                      </p>
                    </div>

                    {/* VIP Sleeper */}
                    <div
                      onClick={() => setSelectedBusClass('VIP Sleeper')}
                      className={`p-6 rounded-3xl border cursor-pointer transition-all ${
                        selectedBusClass === 'VIP Sleeper'
                          ? 'bg-emerald-950/60 border-emerald-400 shadow-[0_0_25px_rgba(16,185,129,0.4)]'
                          : 'bg-black/50 border-white/10'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-extrabold text-white">VIP Sleeper Suite</span>
                        <span className="text-sm font-bold text-emerald-400 font-mono-tech">PKR 7,500</span>
                      </div>
                      <p className="text-xs text-gray-400 mt-2">
                        Full horizontal 180° lie-flat sleeping cabin with privacy curtains, noise insulation, memory foam mattress, and personal storage.
                      </p>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* STEP 03: CHOOSE SEATS (Interactive Seat Map) */}
              {currentStep === 3 && (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-bold text-white font-heading">
                        STEP 03: Select Seats
                      </h3>
                      <p className="text-xs text-gray-400 mt-1">
                        1+2 layout. Selected: <strong className="text-emerald-400">{selectedSeats.join(', ') || 'None'}</strong>
                      </p>
                    </div>
                    {/* Legend */}
                    <div className="flex items-center gap-3 text-[10px] text-gray-400 font-mono-tech">
                      <span className="flex items-center gap-1">
                        <span className="w-2.5 h-2.5 rounded bg-emerald-500" /> Selected
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="w-2.5 h-2.5 rounded bg-neutral-900 border border-white/20" /> Available
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="w-2.5 h-2.5 rounded bg-neutral-800 opacity-50" /> Booked
                      </span>
                    </div>
                  </div>

                  {/* Seat Map Visual Container */}
                  <div className="p-5 rounded-2xl bg-black/60 border border-emerald-500/20 max-w-lg mx-auto">
                    <div className="flex justify-between items-center pb-3 mb-4 border-b border-white/10 text-xs font-mono-tech text-gray-400">
                      <span>FRONT (DRIVER)</span>
                      <span className="text-emerald-400">CABIN ENTRY</span>
                    </div>

                    <div className="space-y-3">
                      {[1, 2, 3, 4].map((row) => {
                        const rowSeats = SEAT_MAP.filter((s) => s.row === row);
                        const seatA = rowSeats.find((s) => s.col === 1);
                        const seatB = rowSeats.find((s) => s.col === 2);
                        const seatC = rowSeats.find((s) => s.col === 3);

                        return (
                          <div key={row} className="flex items-center justify-between gap-3">
                            {/* Solo Seat A */}
                            {seatA && (
                              <button
                                onClick={() => toggleSeat(seatA)}
                                disabled={seatA.isBooked}
                                className={`flex-1 p-2.5 rounded-xl border flex items-center justify-center gap-1 transition-all ${
                                  selectedSeats.includes(seatA.number)
                                    ? 'bg-emerald-500 text-black font-extrabold border-emerald-300 shadow-[0_0_15px_#10b981]'
                                    : seatA.isBooked
                                    ? 'bg-neutral-900/40 border-neutral-800 text-neutral-600 cursor-not-allowed'
                                    : 'bg-neutral-900 border-white/10 hover:border-emerald-500 text-gray-300'
                                }`}
                              >
                                <Armchair className="w-3.5 h-3.5" />
                                <span className="text-xs font-mono-tech font-bold">{seatA.number}</span>
                              </button>
                            )}

                            {/* Aisle */}
                            <div className="w-6 text-center text-[8px] font-mono-tech text-gray-600">
                              AISLE
                            </div>

                            {/* Double Seats B & C */}
                            <div className="flex-[2] flex gap-2">
                              {seatB && (
                                <button
                                  onClick={() => toggleSeat(seatB)}
                                  disabled={seatB.isBooked}
                                  className={`flex-1 p-2.5 rounded-xl border flex items-center justify-center gap-1 transition-all ${
                                    selectedSeats.includes(seatB.number)
                                      ? 'bg-emerald-500 text-black font-extrabold border-emerald-300 shadow-[0_0_15px_#10b981]'
                                      : seatB.isBooked
                                      ? 'bg-neutral-900/40 border-neutral-800 text-neutral-600 cursor-not-allowed'
                                      : 'bg-neutral-900 border-white/10 hover:border-emerald-500 text-gray-300'
                                  }`}
                                >
                                  <Armchair className="w-3.5 h-3.5" />
                                  <span className="text-xs font-mono-tech font-bold">{seatB.number}</span>
                                </button>
                              )}
                              {seatC && (
                                <button
                                  onClick={() => toggleSeat(seatC)}
                                  disabled={seatC.isBooked}
                                  className={`flex-1 p-2.5 rounded-xl border flex items-center justify-center gap-1 transition-all ${
                                    selectedSeats.includes(seatC.number)
                                      ? 'bg-emerald-500 text-black font-extrabold border-emerald-300 shadow-[0_0_15px_#10b981]'
                                      : seatC.isBooked
                                      ? 'bg-neutral-900/40 border-neutral-800 text-neutral-600 cursor-not-allowed'
                                      : 'bg-neutral-900 border-white/10 hover:border-emerald-500 text-gray-300'
                                  }`}
                                >
                                  <Armchair className="w-3.5 h-3.5" />
                                  <span className="text-xs font-mono-tech font-bold">{seatC.number}</span>
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </motion.div>
              )}

              {/* STEP 04: CONFIRMATION & DIGITAL BOARDING PASS */}
              {currentStep === 4 && (
                <motion.div
                  key="step4"
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.96 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-bold text-white font-heading">
                        STEP 04: Confirmed E-Boarding Pass
                      </h3>
                      <p className="text-xs text-gray-400 mt-1">
                        Demo reservation registered in Pakistan Express telemetry system.
                      </p>
                    </div>
                    <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-xs font-bold font-mono-tech">
                      PNR: PE-8842
                    </span>
                  </div>

                  {/* Boarding Pass Card */}
                  <div className="p-6 rounded-3xl bg-gradient-to-br from-neutral-900 via-black to-[#051109] border border-emerald-400 shadow-2xl relative overflow-hidden">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-emerald-950">
                      <div>
                        <div className="text-[10px] font-mono-tech uppercase tracking-widest text-emerald-400">
                          PAKISTAN EXPRESS • KHALID NASIR
                        </div>
                        <div className="text-xl font-extrabold text-white uppercase font-heading mt-0.5">
                          {selectedRoute.from} → {selectedRoute.to}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-extrabold text-emerald-400 font-mono-tech">
                          PKR {calculateTotal().toLocaleString()}
                        </div>
                        <div className="text-[10px] text-gray-400 uppercase">Paid via {paymentMethod}</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-4 border-b border-emerald-950 text-xs">
                      <div>
                        <div className="text-gray-400 text-[10px] uppercase font-mono-tech">Passenger</div>
                        <div className="font-bold text-white mt-0.5">{passengerName}</div>
                      </div>
                      <div>
                        <div className="text-gray-400 text-[10px] uppercase font-mono-tech">Departure</div>
                        <div className="font-bold text-emerald-400 mt-0.5">{selectedRoute.departureTime}</div>
                      </div>
                      <div>
                        <div className="text-gray-400 text-[10px] uppercase font-mono-tech">Seat(s)</div>
                        <div className="font-bold text-white mt-0.5">{selectedSeats.join(', ') || '2A'}</div>
                      </div>
                      <div>
                        <div className="text-gray-400 text-[10px] uppercase font-mono-tech">Class</div>
                        <div className="font-bold text-white mt-0.5">{selectedBusClass}</div>
                      </div>
                    </div>

                    {/* QR Code & Barcode Mock */}
                    <div className="mt-4 flex items-center justify-between pt-2">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-xl bg-white text-black">
                          <QrCode className="w-8 h-8" />
                        </div>
                        <div className="text-[10px] font-mono-tech text-gray-400">
                          <span>SCAN AT TERMINAL GATE</span>
                          <div className="text-emerald-400 font-bold">SMART BOARDING ENABLED</div>
                        </div>
                      </div>
                      <div className="text-right text-[10px] text-gray-500 font-mono-tech">
                        * Visual Prototype Demo
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

            </AnimatePresence>
          </div>

          {/* Navigation Controls */}
          <div className="pt-6 border-t border-emerald-950/80 flex items-center justify-between">
            <button
              onClick={() => setCurrentStep((prev) => Math.max(prev - 1, 1))}
              disabled={currentStep === 1}
              className={`px-5 py-2.5 rounded-xl border text-xs uppercase font-bold tracking-wider flex items-center gap-2 ${
                currentStep === 1
                  ? 'opacity-30 cursor-not-allowed border-neutral-800 text-gray-600'
                  : 'bg-black/40 border-white/10 hover:border-emerald-500 text-gray-300'
              }`}
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Previous</span>
            </button>

            <button
              onClick={() => setCurrentStep((prev) => (prev < 4 ? prev + 1 : 1))}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-400 text-black font-extrabold text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(16,185,129,0.4)] flex items-center gap-2 hover:scale-105 transition-all"
            >
              <span>{currentStep === 4 ? 'Restart Demo' : 'Next Step'}</span>
              <ArrowRight className="w-3.5 h-3.5 text-black" />
            </button>
          </div>

        </div>
      </div>
    </section>
  );
};
