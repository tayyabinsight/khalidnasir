import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Search, Bus, CheckCircle2, Clock, MapPin, Gauge, Radio, ShieldCheck } from 'lucide-react';

interface TrackBookingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TrackBookingModal: React.FC<TrackBookingModalProps> = ({ isOpen, onClose }) => {
  const [pnr, setPnr] = useState('PE-8842');
  const [isSearching, setIsSearching] = useState(false);
  const [ticketData, setTicketData] = useState<{
    pnr: string;
    route: string;
    coachNumber: string;
    driver: string;
    departure: string;
    eta: string;
    currentLocation: string;
    speed: string;
    status: string;
    passenger: string;
    seats: string;
  } | null>({
    pnr: 'PE-8842',
    route: 'Karachi Central → Rawalpindi Faizabad Hub',
    coachNumber: 'PE-VIP-102 (Scania Touring)',
    driver: 'Captain Ghulam Rasool (Senior Motorway Pilot)',
    departure: '08:00 PM (Departed on time)',
    eta: '02:15 PM Tomorrow',
    currentLocation: 'M-5 Motorway — Passing Rohri/Pano Aqil Corridor',
    speed: '96 km/h',
    status: 'Cruising Smoothly • On Schedule',
    passenger: 'Hamza Ali Khan',
    seats: '1A (Solo First-Class)',
  });

  if (!isOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSearching(true);
    setTimeout(() => {
      setIsSearching(false);
      setTicketData({
        pnr: pnr.toUpperCase() || 'PE-8842',
        route: 'Karachi Central → Rawalpindi Faizabad Hub',
        coachNumber: 'PE-VIP-102 (Scania Touring)',
        driver: 'Captain Ghulam Rasool (Senior Motorway Pilot)',
        departure: '08:00 PM (Departed on time)',
        eta: '02:15 PM Tomorrow',
        currentLocation: 'M-5 Motorway — Approaching Multan Junction',
        speed: '98 km/h',
        status: 'Cruising Smoothly • On Schedule',
        passenger: 'Tariq Mehmood',
        seats: '2A, 2B',
      });
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/85 backdrop-blur-xl">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-xl bg-[#060a08] border border-emerald-500/40 rounded-3xl p-6 sm:p-8 shadow-[0_25px_80px_rgba(0,0,0,0.95)] text-white"
      >
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 rounded-full bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 pb-5 border-b border-emerald-950/80">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-950 flex items-center justify-center border border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.4)]">
            <Radio className="w-5 h-5 text-white animate-pulse" />
          </div>
          <div>
            <h3 className="text-xl font-bold uppercase tracking-wide font-heading">
              Live Coach & PNR Radar
            </h3>
            <p className="text-xs text-emerald-400 font-mono-tech">
              24/7 Satellite Telemetry Tracking
            </p>
          </div>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="mt-6 flex gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              value={pnr}
              onChange={(e) => setPnr(e.target.value)}
              placeholder="Enter PNR Ticket Number (e.g. PE-8842)"
              className="w-full py-3.5 px-4 rounded-xl bg-black/60 border border-emerald-500/40 text-white font-mono-tech uppercase text-sm focus:outline-none focus:border-emerald-400"
            />
          </div>
          <button
            type="submit"
            disabled={isSearching}
            className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-400 text-black font-extrabold text-xs uppercase tracking-wider shadow-[0_0_15px_rgba(16,185,129,0.4)] flex items-center gap-2"
          >
            <Search className="w-4 h-4" />
            <span>{isSearching ? 'Tracking...' : 'Locate'}</span>
          </button>
        </form>

        {/* Result Card */}
        {ticketData && (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6 p-5 rounded-2xl bg-black/60 border border-emerald-500/30 space-y-4"
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <span className="text-sm font-bold text-white font-heading">{ticketData.route}</span>
              <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-mono-tech font-bold">
                {ticketData.pnr}
              </span>
            </div>

            <div className="space-y-2.5 text-xs text-gray-300">
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Current Position:</span>
                <span className="text-emerald-400 font-bold font-mono-tech">{ticketData.currentLocation}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Telemetry Speed:</span>
                <span className="font-mono-tech text-white font-bold">{ticketData.speed}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Coach / Fleet:</span>
                <span className="font-bold text-white">{ticketData.coachNumber}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Motorway Captain:</span>
                <span className="text-gray-200">{ticketData.driver}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Estimated Arrival:</span>
                <span className="text-emerald-300 font-bold">{ticketData.eta}</span>
              </div>
            </div>

            <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[11px] font-mono-tech text-emerald-400">
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {ticketData.status}
              </span>
              <span className="text-gray-400">GPS Signal: 100%</span>
            </div>
          </motion.div>
        )}

      </motion.div>
    </div>
  );
};
