import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Navigation, Compass, ArrowUpRight, Zap, Sparkles, Building2, Calendar } from 'lucide-react';
import { MAP_CITIES, MAP_CONNECTIONS } from '../data/mockData';
import { CityNode } from '../types';

interface PakistanMapSectionProps {
  onSelectCityRoute: (city: string) => void;
}

export const PakistanMapSection: React.FC<PakistanMapSectionProps> = ({ onSelectCityRoute }) => {
  const [selectedCity, setSelectedCity] = useState<CityNode | null>(MAP_CITIES[0]); // default Karachi
  const [hoveredCity, setHoveredCity] = useState<CityNode | null>(null);

  const activeCity = hoveredCity || selectedCity;

  return (
    <section id="network-map" className="relative py-24 bg-[#030604] text-white overflow-hidden border-t border-emerald-950/40">
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[60vw] h-[60vh] bg-emerald-950/15 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-950/70 border border-emerald-500/30 text-emerald-400 text-xs font-mono-tech uppercase tracking-widest mb-4 shadow-[0_0_20px_rgba(16,185,129,0.2)]"
          >
            <Compass className="w-3.5 h-3.5" />
            <span>INTERCITY MOTORWAY NETWORK</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white uppercase font-heading"
          >
            One Network. <br className="sm:hidden" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-emerald-300 to-white">
              Countless Journeys.
            </span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="mt-4 text-sm sm:text-base text-gray-300 max-w-2xl mx-auto"
          >
            Explore the nationwide transit network connecting Pakistan's economic hubs and scenic northern corridors with direct express connectivity.
          </motion.p>
        </div>

        {/* Map & Detail Cards Container */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left / Main Column: The Interactive Dark Vector Map */}
          <div className="lg:col-span-8 relative">
            <div className="relative w-full aspect-[4/3] sm:aspect-[16/11] bg-black/60 rounded-3xl border border-emerald-500/20 p-4 sm:p-8 overflow-hidden shadow-[0_20px_60px_rgba(0,0,0,0.9)]">
              
              {/* Subtle Map Grid Background */}
              <div className="absolute inset-0 bg-[linear-gradient(to_right,#10b981_1px,transparent_1px),linear-gradient(to_bottom,#10b981_1px,transparent_1px)] bg-[size:3rem_3rem] opacity-5" />

              {/* Decorative Radar Sweep Line */}
              <div className="absolute inset-0 pointer-events-none opacity-20">
                <div className="w-full h-full bg-[conic-gradient(from_0deg_at_50%_50%,rgba(16,185,129,0.3)_0deg,transparent_60deg)] animate-spin" style={{ animationDuration: '16s' }} />
              </div>

              {/* Simplified Geometric Pakistan Map Contour SVG */}
              <svg viewBox="0 0 100 100" className="w-full h-full absolute inset-0 z-0 opacity-25 filter drop-shadow-[0_0_10px_#10b981]">
                {/* Stylized Pakistan Geography Contour */}
                <path
                  d="M20 90 Q 25 80, 28 75 T 32 60 T 36 50 T 40 40 T 45 30 T 52 20 T 58 12 T 65 5 Q 70 8, 68 15 T 62 25 T 58 35 T 52 45 T 48 55 T 42 65 T 36 78 T 28 88 Z"
                  fill="rgba(16, 185, 129, 0.08)"
                  stroke="rgba(16, 185, 129, 0.4)"
                  strokeWidth="0.5"
                  strokeDasharray="2, 1"
                />
              </svg>

              {/* Glowing SVG Animated Connecting Transit Lines */}
              <svg viewBox="0 0 100 100" className="w-full h-full absolute inset-0 z-10 pointer-events-none">
                <defs>
                  <linearGradient id="routeGradient" x1="0%" y1="100%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#059669" stopOpacity="0.4" />
                    <stop offset="50%" stopColor="#10b981" stopOpacity="0.9" />
                    <stop offset="100%" stopColor="#34d399" stopOpacity="0.6" />
                  </linearGradient>
                  <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="0.8" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                </defs>

                {/* Draw static highway corridors */}
                {MAP_CONNECTIONS.map((conn, idx) => {
                  const fromNode = MAP_CITIES.find((c) => c.id === conn.from);
                  const toNode = MAP_CITIES.find((c) => c.id === conn.to);
                  if (!fromNode || !toNode) return null;

                  return (
                    <line
                      key={idx}
                      x1={fromNode.x}
                      y1={fromNode.y}
                      x2={toNode.x}
                      y2={toNode.y}
                      stroke="rgba(16, 185, 129, 0.4)"
                      strokeWidth="0.8"
                      strokeDasharray="1.5, 1"
                    />
                  );
                })}

                {/* Animated Glowing Main Trunk Arterial Line (Karachi -> Sukkur -> Multan -> Faisalabad -> Rawalpindi -> Abbottabad) */}
                <path
                  d="M 26 88 L 30 80 L 35 68 L 44 56 L 48 48 L 55 40 L 58 17 L 61 15 L 63 9 L 65 6"
                  fill="none"
                  stroke="url(#routeGradient)"
                  strokeWidth="1.2"
                  filter="url(#glow)"
                />

                {/* Traveling light pulse node along the main trunk */}
                <circle r="1.2" fill="#ffffff" filter="url(#glow)">
                  <animateMotion
                    path="M 26 88 L 30 80 L 35 68 L 44 56 L 48 48 L 55 40 L 58 17 L 61 15 L 63 9 L 65 6"
                    dur="7s"
                    repeatCount="indefinite"
                  />
                </circle>

                {/* Reverse pulse (Rawalpindi down to Karachi) */}
                <circle r="1.0" fill="#34d399" filter="url(#glow)">
                  <animateMotion
                    path="M 65 6 L 63 9 L 61 15 L 58 17 L 55 40 L 48 48 L 44 56 L 35 68 L 30 80 L 26 88"
                    dur="9s"
                    repeatCount="indefinite"
                  />
                </circle>
              </svg>

              {/* City Nodes (Interactive HTML / Motion elements on top) */}
              <div className="absolute inset-0 z-20">
                {MAP_CITIES.map((city) => {
                  const isSelected = activeCity?.id === city.id;
                  return (
                    <div
                      key={city.id}
                      style={{ left: `${city.x}%`, top: `${city.y}%` }}
                      className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer group"
                      onMouseEnter={() => setHoveredCity(city)}
                      onMouseLeave={() => setHoveredCity(null)}
                      onClick={() => setSelectedCity(city)}
                    >
                      {/* Pulse ring for major cities or selected */}
                      {(city.isMajor || isSelected) && (
                        <div
                          className={`absolute -inset-2 rounded-full animate-ping opacity-60 ${
                            isSelected ? 'bg-white' : 'bg-emerald-400'
                          }`}
                        />
                      )}

                      {/* City Marker Node */}
                      <div
                        className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center transition-all duration-300 ${
                          isSelected
                            ? 'bg-white border-emerald-300 scale-150 shadow-[0_0_15px_#ffffff]'
                            : city.isMajor
                            ? 'bg-emerald-400 border-emerald-200 shadow-[0_0_10px_#10b981]'
                            : 'bg-emerald-950 border-emerald-500/70 hover:bg-emerald-400'
                        }`}
                      >
                        <div className={`w-1 h-1 rounded-full ${isSelected ? 'bg-black' : 'bg-white'}`} />
                      </div>

                      {/* City Label */}
                      <div
                        className={`absolute left-4 top-1/2 -translate-y-1/2 whitespace-nowrap px-2 py-0.5 rounded text-[10px] font-mono-tech transition-all pointer-events-none ${
                          isSelected
                            ? 'bg-black/90 border border-emerald-400 text-white font-bold shadow-lg scale-110'
                            : 'text-gray-300 group-hover:text-emerald-300 bg-black/60 group-hover:bg-black/80'
                        }`}
                      >
                        <span>{city.name}</span>
                        {city.isMajor && (
                          <span className="ml-1 text-[8px] text-emerald-400 font-bold">★</span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Map Footer Note */}
              <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-[10px] font-mono-tech text-gray-400">
                <span className="flex items-center gap-1 text-emerald-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  M-2, M-4, M-5 & M-15 EXPRESS ROUTE MESH
                </span>
                <span className="text-gray-500 hidden sm:inline">
                  Interactive Node Network
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Selected City Hub Card & Network Stats */}
          <div className="lg:col-span-4 flex flex-col gap-5">
            {activeCity ? (
              <motion.div
                key={activeCity.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                className="glass-panel-glow rounded-3xl p-6 border border-emerald-500/40 shadow-2xl relative overflow-hidden"
              >
                <div className="flex items-center justify-between pb-4 border-b border-emerald-950/70">
                  <div>
                    <span className="text-[10px] font-mono-tech uppercase tracking-widest text-emerald-400">
                      DESTINATION HUB
                    </span>
                    <h3 className="text-2xl font-bold text-white tracking-wide font-heading">
                      {activeCity.name}
                    </h3>
                  </div>
                  <div className="text-right">
                    <span className="text-lg font-bold text-emerald-400 font-mono-tech">
                      {activeCity.urduName}
                    </span>
                  </div>
                </div>

                <div className="mt-5 space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-xs text-gray-400 flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-emerald-400" />
                      Terminals & Lounges
                    </span>
                    <span className="text-xs font-bold text-white">
                      {activeCity.terminals} Dedicated Lounges
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-3 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-xs text-gray-400 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                      Daily Departures
                    </span>
                    <span className="text-xs font-bold text-emerald-400 font-mono-tech">
                      {activeCity.dailyDepartures}+ Coaches
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-3 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-xs text-gray-400 flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5 text-emerald-400" />
                      Fleet Class
                    </span>
                    <span className="text-xs font-bold text-white">
                      Royal Executive & Sleeper
                    </span>
                  </div>
                </div>

                {/* Direct Booking for this City */}
                <button
                  onClick={() => onSelectCityRoute(activeCity.name)}
                  className="w-full mt-6 py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-400 text-black font-extrabold text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(16,185,129,0.4)] hover:shadow-[0_0_30px_rgba(16,185,129,0.7)] flex items-center justify-center gap-2 group transition-all"
                >
                  <span>View Departures from {activeCity.name}</span>
                  <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                </button>
              </motion.div>
            ) : null}

            {/* Quick Network Stat Highlights */}
            <div className="p-5 rounded-3xl bg-black/40 border border-emerald-950/80 flex items-center justify-between">
              <div>
                <div className="text-2xl font-extrabold text-white font-mono-tech">16+</div>
                <div className="text-[11px] text-gray-400 uppercase tracking-wider">Connected Cities</div>
              </div>
              <div className="h-8 w-[1px] bg-emerald-900/50" />
              <div>
                <div className="text-2xl font-extrabold text-emerald-400 font-mono-tech">350+</div>
                <div className="text-[11px] text-gray-400 uppercase tracking-wider">Daily Trips</div>
              </div>
              <div className="h-8 w-[1px] bg-emerald-900/50" />
              <div>
                <div className="text-2xl font-extrabold text-white font-mono-tech">24/7</div>
                <div className="text-[11px] text-gray-400 uppercase tracking-wider">Live Tracking</div>
              </div>
            </div>

            {/* Verified Network Note */}
            <p className="text-[11px] text-gray-400 leading-relaxed italic px-2">
              * Route connectivity and stops are scheduled for optimal motorway transit times between major city terminals.
            </p>
          </div>

        </div>
      </div>
    </section>
  );
};
