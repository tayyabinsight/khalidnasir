import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Sparkles, Bus, ShieldCheck, PhoneCall, MessageSquare } from 'lucide-react';
import { ASSETS } from '../data/mockData';

interface FinalCTASectionProps {
  onOpenBooking: () => void;
  onOpenWhatsApp: () => void;
}

export const FinalCTASection: React.FC<FinalCTASectionProps> = ({ onOpenBooking, onOpenWhatsApp }) => {
  return (
    <section id="final-cta" className="relative py-28 bg-[#050505] text-white overflow-hidden border-t border-white/10">
      
      {/* Background Cinematic Bus & Moving Highway */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <img
          src={ASSETS.heroBus}
          alt="Pakistan Express Night Motorway Journey"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover filter contrast-125 brightness-40 transform scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-black/85 to-[#050505]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.18)_0%,transparent_70%)]" />
      </div>

      {/* Grid pattern overlay */}
      <div className="absolute inset-0 immersive-grid-pattern opacity-50 pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center flex flex-col items-center">
        
        {/* Top Tag */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 text-xs font-mono-tech tracking-widest uppercase mb-6 backdrop-blur-md shadow-[0_0_20px_rgba(16,185,129,0.25)]"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>RESERVE YOUR VIP SUITE TODAY</span>
        </motion.div>

        {/* Big Heading */}
        <motion.h2
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="text-4xl sm:text-6xl md:text-7xl font-black tracking-tight text-white uppercase font-heading leading-tight"
        >
          Where Will Your <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-emerald-200 to-white drop-shadow-[0_0_35px_rgba(16,185,129,0.4)]">
            Journey Take You?
          </span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="mt-6 text-base sm:text-lg text-emerald-100/70 max-w-2xl leading-relaxed font-light"
        >
          Whether traveling for urgent business, family reunions, or northern vacations, step aboard Pakistan Express and redefine your expectations of long-distance comfort.
        </motion.p>

        {/* Main CTA Button with Pulsing Emerald Halo */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="mt-10 relative group"
        >
          {/* Green Glow Behind CTA */}
          <div className="absolute -inset-2 bg-emerald-500 rounded-full blur-xl opacity-60 group-hover:opacity-100 animate-pulse transition duration-500" />

          <button
            onClick={onOpenBooking}
            id="final-book-seat-btn"
            className="relative px-10 py-5 rounded-sm bg-emerald-400 hover:bg-emerald-300 text-black font-black text-base uppercase tracking-widest shadow-[0_0_40px_rgba(16,185,129,0.8)] hover:shadow-[0_0_60px_rgba(16,185,129,1)] hover:scale-105 transition-all duration-300 flex items-center gap-3"
          >
            <span className="relative z-10 text-black">Book Your Seat</span>
            <ArrowRight className="w-5 h-5 text-black group-hover:translate-x-1.5 transition-transform" />
          </button>
        </motion.div>

        {/* WhatsApp & Helpline Quick Actions */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-4 text-xs font-mono-tech text-gray-300">
          <button
            onClick={onOpenWhatsApp}
            className="px-4 py-2 rounded-sm bg-white/5 hover:bg-white/10 border border-white/10 hover:border-emerald-500/40 text-emerald-300 flex items-center gap-2 transition-all"
          >
            <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
            <span>24/7 WhatsApp Booking Desk</span>
          </button>

          <span className="text-gray-600 hidden sm:inline">•</span>

          <span className="flex items-center gap-1.5 text-gray-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            Guaranteed Punctuality & Verified Safety
          </span>
        </div>

      </div>
    </section>
  );
};
