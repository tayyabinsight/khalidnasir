import React from 'react';
import { motion } from 'motion/react';
import { Shield, Sparkles, Clock, Wifi, CheckCircle2, ChevronRight } from 'lucide-react';
import { ASSETS } from '../data/mockData';

interface JourneyStartsSectionProps {
  onOpenBooking: () => void;
}

export const JourneyStartsSection: React.FC<JourneyStartsSectionProps> = ({ onOpenBooking }) => {
  const highlights = [
    { title: 'Punctual Departures', desc: 'Precision motorway scheduling with 99.4% on-time record.' },
    { title: 'Zero-Gravity Seating', desc: '160° pneumatic recliners with calf & lumbar support.' },
    { title: 'VIP Passenger Lounge', desc: 'Executive terminal lounges with refreshments & priority boarding.' },
    { title: '24/7 Satellite Telemetry', desc: 'Active motorway command center monitoring speed & safety.' },
  ];

  return (
    <section id="journey-starts" className="relative py-24 bg-[#050505] text-white overflow-hidden border-t border-white/10">
      {/* Background atmospheric radial glow (Immersive UI) */}
      <div className="absolute top-0 right-1/4 w-[50vw] h-[50vh] bg-emerald-950/20 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute -bottom-10 left-10 w-[30vw] h-[30vh] bg-emerald-900/10 rounded-full blur-[100px] pointer-events-none" />
      
      {/* Ambient Grid overlay */}
      <div className="absolute inset-0 immersive-grid-pattern opacity-60 pointer-events-none" />

      {/* Speed lines & Horizon Accent */}
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-emerald-500/30 to-transparent" />

      {/* Floating Road Spark Particles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {Array.from({ length: 16 }).map((_, i) => (
          <motion.div
            key={i}
            animate={{
              y: [-20, -200],
              x: [(i % 2 === 0 ? 10 : -10), (i % 2 === 0 ? -30 : 30)],
              opacity: [0, 0.8, 0],
            }}
            transition={{
              duration: 4 + (i % 3),
              repeat: Infinity,
              delay: (i * 0.4) % 3,
              ease: 'easeOut',
            }}
            style={{
              left: `${(i * 6.5) + 5}%`,
              bottom: '5%',
            }}
            className="absolute w-1.5 h-1.5 rounded-full bg-emerald-400 blur-[1px]"
          />
        ))}
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Typography & Craft Details */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-6 flex flex-col items-start"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 text-xs font-mono-tech tracking-widest uppercase mb-4 backdrop-blur-md">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>THE STANDARD OF MOTORWAY EXCELLENCE</span>
            </div>

            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white uppercase font-heading leading-none">
              The Journey <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-emerald-200 to-white drop-shadow-[0_0_30px_rgba(16,185,129,0.35)]">
                Starts Here.
              </span>
            </h2>

            <p className="mt-5 text-base sm:text-lg text-emerald-100/70 leading-relaxed max-w-xl font-light">
              From city streets to long highways, travel with confidence, comfort, and convenience. Under the visionary stewardship of <strong className="text-emerald-400 font-semibold">Khalid Nasir</strong>, Pakistan Express is engineered for those who value time, dignity, and serenity on every mile.
            </p>

            {/* Feature Highlights Grid */}
            <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4 w-full">
              {highlights.map((item, idx) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 15 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1, duration: 0.5 }}
                  className="p-4 rounded-xl bg-white/5 border border-white/10 hover:border-emerald-500/40 transition-colors"
                >
                  <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{item.title}</span>
                  </div>
                  <p className="mt-1 text-xs text-gray-400 leading-normal">
                    {item.desc}
                  </p>
                </motion.div>
              ))}
            </div>

            {/* Experience CTA */}
            <div className="mt-8">
              <button
                onClick={onOpenBooking}
                className="px-6 py-3.5 rounded-sm bg-white/5 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:border-emerald-400 font-bold text-xs uppercase tracking-widest flex items-center gap-2 transition-all group"
              >
                <span>Discover Travel Classes</span>
                <ChevronRight className="w-4 h-4 text-emerald-400 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </motion.div>

          {/* Right Column: Animated Bus Entering Visual */}
          <motion.div
            initial={{ opacity: 0, x: 60, scale: 0.95 }}
            whileInView={{ opacity: 1, x: 0, scale: 1 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 relative"
          >
            <div className="relative rounded-2xl overflow-hidden border border-white/15 shadow-[0_25px_60px_rgba(0,0,0,0.9)] group">
              <img
                src={ASSETS.busShowcase}
                alt="Pakistan Express luxury touring coach visual"
                referrerPolicy="no-referrer"
                className="w-full h-auto object-cover transform group-hover:scale-105 transition-transform duration-700 filter brightness-105"
              />

              {/* Gradient Overlays */}
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80" />
              <div className="absolute inset-0 bg-gradient-to-r from-black/40 via-transparent to-transparent" />

              {/* Floating Stat Badge */}
              <div className="absolute bottom-5 left-5 right-5 p-4 rounded-xl bg-black/85 backdrop-blur-md border border-white/10 flex items-center justify-between shadow-xl">
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-emerald-400 font-mono-tech">
                    FLEET SPECIFICATION
                  </div>
                  <div className="text-sm sm:text-base font-bold text-white">
                    Scania Intercity Touring Class • Euro-VI
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xl font-extrabold text-emerald-400 font-mono-tech">
                    100%
                  </div>
                  <div className="text-[10px] text-gray-400 uppercase">
                    Air Conditioned
                  </div>
                </div>
              </div>
            </div>

            {/* Glowing Accent Ring behind the image */}
            <div className="absolute -inset-4 bg-emerald-500/10 rounded-[2.5rem] blur-2xl -z-10 pointer-events-none" />
          </motion.div>

        </div>
      </div>
    </section>
  );
};
