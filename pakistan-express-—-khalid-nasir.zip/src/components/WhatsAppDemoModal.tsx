import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Send, MessageSquare, Check, ShieldCheck, Bus } from 'lucide-react';

interface WhatsAppDemoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WhatsAppDemoModal: React.FC<WhatsAppDemoModalProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<Array<{ sender: 'bot' | 'user'; text: string; time: string }>>([
    {
      sender: 'bot',
      text: 'Assalam-o-Alaikum! Welcome to Pakistan Express (Khalid Nasir) Official Booking Desk. How may we assist your journey today?',
      time: '08:00 AM',
    },
    {
      sender: 'bot',
      text: 'Popular routes right now:\n1. Karachi ⇄ Rawalpindi (VIP Sleeper)\n2. Multan ⇄ Rawalpindi (Royal Executive)\n3. Faisalabad ⇄ Islamabad',
      time: '08:01 AM',
    },
  ]);
  const [inputText, setInputText] = useState('');

  if (!isOpen) return null;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const userMsg = inputText.trim();
    const timeNow = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setMessages((prev) => [
      ...prev,
      { sender: 'user', text: userMsg, time: timeNow },
    ]);
    setInputText('');

    // Simulated automated assistant response
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          sender: 'bot',
          text: `Thank you for inquiring about "${userMsg}". Our terminal officer will confirm current luxury seat availability. You can also use our instant on-page seat selection portal anytime!`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/85 backdrop-blur-xl">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-md bg-[#09150d] border border-emerald-500/40 rounded-3xl overflow-hidden shadow-[0_25px_80px_rgba(0,0,0,0.95)] text-white flex flex-col h-[520px]"
      >
        {/* WhatsApp Header */}
        <div className="p-4 bg-emerald-950 border-b border-emerald-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-emerald-500 flex items-center justify-center text-black font-extrabold shadow-lg">
                <Bus className="w-5 h-5 text-black" />
              </div>
              <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-400 border-2 border-black rounded-full" />
            </div>

            <div>
              <div className="text-sm font-bold text-white flex items-center gap-1.5">
                <span>Pakistan Express Support</span>
                <span className="text-emerald-400 text-xs">✓</span>
              </div>
              <div className="text-[10px] text-emerald-400 font-mono-tech">
                Khalid Nasir Official Booking Desk
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-white/10 text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-[radial-gradient(#10b981_0.5px,transparent_0.5px)] [background-size:16px_16px] bg-black/60">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[82%] p-3 rounded-2xl text-xs leading-relaxed whitespace-pre-line ${
                  m.sender === 'user'
                    ? 'bg-emerald-600 text-black font-medium rounded-tr-none'
                    : 'bg-neutral-900 border border-emerald-500/20 text-gray-200 rounded-tl-none'
                }`}
              >
                {m.text}
              </div>
              <span className="text-[9px] text-gray-500 mt-1 px-1 font-mono-tech">{m.time}</span>
            </div>
          ))}
        </div>

        {/* Input Bar */}
        <form onSubmit={handleSend} className="p-3 bg-neutral-950 border-t border-emerald-950/80 flex gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Type your message..."
            className="flex-1 px-4 py-2.5 rounded-full bg-neutral-900 border border-emerald-500/30 text-xs text-white focus:outline-none focus:border-emerald-400"
          />
          <button
            type="submit"
            className="p-2.5 rounded-full bg-emerald-500 text-black hover:bg-emerald-400 transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </motion.div>
    </div>
  );
};
