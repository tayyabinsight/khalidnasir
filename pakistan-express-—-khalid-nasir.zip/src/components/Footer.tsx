import React from 'react';
import { Bus, MapPin, Phone, Mail, MessageSquare, Moon, Sun, Shield, Sparkles, ArrowUp } from 'lucide-react';

interface FooterProps {
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  onOpenBooking: () => void;
  onOpenTrack: () => void;
  onOpenWhatsApp: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  darkMode,
  setDarkMode,
  onOpenBooking,
  onOpenTrack,
  onOpenWhatsApp,
}) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer id="footer" className="relative bg-[#050505] text-white pt-16 pb-12 border-t border-white/10 overflow-hidden">
      {/* Immersive grid background */}
      <div className="absolute inset-0 immersive-grid-pattern opacity-30 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-white/10">
          
          {/* Col 1: Brand Info (2 cols on lg) */}
          <div className="lg:col-span-2 flex flex-col items-start">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-sm bg-emerald-500/10 flex items-center justify-center border border-emerald-500/30 text-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.25)]">
                <Bus className="w-5 h-5" />
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-black tracking-widest text-white uppercase font-heading">
                  Pakistan <span className="text-emerald-400">Express</span>
                </span>
                <span className="text-[10px] tracking-widest uppercase text-emerald-400 font-mono-tech">
                  Khalid Nasir
                </span>
              </div>
            </div>

            <p className="mt-4 text-xs sm:text-sm text-emerald-100/60 leading-relaxed max-w-sm font-light">
              Pakistan's flagship intercity executive coach service. Connecting major metropolitan and regional terminals with unprecedented speed, luxury, and digital convenience.
            </p>

            <div className="mt-6 flex items-center gap-3">
              <button
                onClick={onOpenWhatsApp}
                className="px-4 py-2 rounded-sm bg-white/5 hover:bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center gap-2 transition-colors"
              >
                <MessageSquare className="w-4 h-4 text-emerald-400" />
                <span>WhatsApp Booking</span>
              </button>

              <button
                onClick={() => setDarkMode(!darkMode)}
                className="p-2.5 rounded-sm bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white border border-white/10 transition-colors"
                aria-label="Toggle theme"
              >
                {darkMode ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4 text-emerald-400" />}
              </button>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div>
            <h4 className="text-xs font-bold font-mono-tech uppercase tracking-widest text-emerald-400 mb-4">
              Quick Navigation
            </h4>
            <ul className="space-y-2.5 text-xs text-gray-400">
              <li>
                <a href="#hero" className="hover:text-emerald-400 transition-colors">Home Experience</a>
              </li>
              <li>
                <a href="#routes" className="hover:text-emerald-400 transition-colors">Route Schedules</a>
              </li>
              <li>
                <a href="#network-map" className="hover:text-emerald-400 transition-colors">Transit Network Map</a>
              </li>
              <li>
                <a href="#fleet" className="hover:text-emerald-400 transition-colors">Fleet Specifications</a>
              </li>
              <li>
                <a href="#live-status" className="hover:text-emerald-400 transition-colors">Live Coach Radar</a>
              </li>
            </ul>
          </div>

          {/* Col 3: Services & Support */}
          <div>
            <h4 className="text-xs font-bold font-mono-tech uppercase tracking-widest text-emerald-400 mb-4">
              Passenger Services
            </h4>
            <ul className="space-y-2.5 text-xs text-gray-400">
              <li>
                <button onClick={onOpenBooking} className="hover:text-emerald-400 transition-colors">
                  Instant Seat Reservation
                </button>
              </li>
              <li>
                <button onClick={onOpenTrack} className="hover:text-emerald-400 transition-colors">
                  Track PNR Booking
                </button>
              </li>
              <li>
                <a href="#features" className="hover:text-emerald-400 transition-colors">VIP Lounge Access</a>
              </li>
              <li>
                <a href="#experience" className="hover:text-emerald-400 transition-colors">Luggage Policy (30kg)</a>
              </li>
              <li>
                <button onClick={onOpenWhatsApp} className="hover:text-emerald-400 transition-colors">
                  24/7 Helpline Desk
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Key Terminals */}
          <div>
            <h4 className="text-xs font-bold font-mono-tech uppercase tracking-widest text-emerald-400 mb-4">
              Primary Terminals
            </h4>
            <ul className="space-y-2.5 text-xs text-gray-400 font-mono-tech">
              <li className="flex items-start gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span>Karachi: Sohrab Goth & Saddar</span>
              </li>
              <li className="flex items-start gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span>Rawalpindi: Faizabad Intercity Hub</span>
              </li>
              <li className="flex items-start gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span>Multan: Khanewal Road Terminal</span>
              </li>
              <li className="flex items-start gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span>Lahore: Thokar Niaz Baig Lounge</span>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-400">
          <div className="flex items-center gap-2">
            <span>© 2026 Pakistan Express — Khalid Nasir. All Rights Reserved.</span>
          </div>

          <div className="flex items-center gap-6">
            <span className="text-gray-400">Front-End Animated Showcase Demo</span>
            <button
              onClick={scrollToTop}
              className="p-2 rounded-sm bg-white/5 hover:bg-emerald-500/20 text-gray-400 hover:text-emerald-400 border border-white/10 transition-colors flex items-center gap-1"
              aria-label="Back to top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
