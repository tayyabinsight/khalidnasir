import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Eye, Info, X, Check, ShieldCheck, Armchair, Wifi, Zap } from 'lucide-react';
import { ASSETS, BUS_HOTSPOTS } from '../data/mockData';
import { BusHotspot } from '../types';

export const BusShowcaseSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'exterior' | 'interior'>('exterior');
  const [selectedHotspot, setSelectedHotspot] = useState<BusHotspot | null>(null);

  return (
    <section id="fleet" className="relative py-24 bg-[#020403] text-white overflow-hidden border-t border-emerald-950/40">
      {/* Background Lighting */}
      <div className="absolute top-1/4 right-10 w-[55vw] h-[55vh] bg-emerald-950/20 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-950/70 border border-emerald-500/30 text-emerald-400 text-xs font-mono-tech uppercase tracking-widest mb-4"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AERODYNAMIC ARCHITECTURE & BESPOKE LUXURY</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white uppercase font-heading"
          >
            The Royal Fleet <br className="sm:hidden" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-emerald-300 to-white">
              Showcase
            </span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="mt-4 text-sm sm:text-base text-gray-300"
          >
            Explore the flagship Pakistan Express touring coach. Click the interactive hotspots to inspect comfort engineering and safety telemetry.
          </motion.p>

          {/* Exterior vs Interior Toggle */}
          <div className="mt-8 inline-flex items-center p-1.5 rounded-full bg-black/80 border border-emerald-500/30 backdrop-blur-md">
            <button
              onClick={() => {
                setActiveTab('exterior');
                setSelectedHotspot(null);
              }}
              className={`px-6 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider transition-all duration-300 ${
                activeTab === 'exterior'
                  ? 'bg-gradient-to-r from-emerald-600 to-emerald-400 text-black shadow-[0_0_20px_rgba(16,185,129,0.5)]'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Exterior Profile
            </button>
            <button
              onClick={() => {
                setActiveTab('interior');
                setSelectedHotspot(null);
              }}
              className={`px-6 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider transition-all duration-300 ${
                activeTab === 'interior'
                  ? 'bg-gradient-to-r from-emerald-600 to-emerald-400 text-black shadow-[0_0_20px_rgba(16,185,129,0.5)]'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              VIP First-Class Cabin
            </button>
          </div>
        </div>

        {/* Showcase Stage Frame */}
        <div className="relative rounded-3xl overflow-hidden border border-emerald-500/30 bg-black/80 shadow-[0_25px_70px_rgba(0,0,0,0.9)]">
          
          {/* Main Visual with Motion Parallax Entry */}
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.6 }}
              className="relative w-full aspect-[16/9] max-h-[600px] overflow-hidden"
            >
              <img
                src={activeTab === 'exterior' ? ASSETS.busShowcase : ASSETS.busInterior}
                alt={activeTab === 'exterior' ? 'Pakistan Express Bus Exterior' : 'Pakistan Express Luxury Cabin Interior'}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover filter contrast-105 brightness-105"
              />

              {/* Cinematic Vignette Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/30 pointer-events-none" />

              {/* Interactive Hotspots on the visual */}
              {activeTab === 'exterior' &&
                BUS_HOTSPOTS.map((spot) => {
                  const isSelected = selectedHotspot?.id === spot.id;
                  return (
                    <div
                      key={spot.id}
                      style={{ left: `${spot.x}%`, top: `${spot.y}%` }}
                      className="absolute -translate-x-1/2 -translate-y-1/2 z-20"
                    >
                      <button
                        onClick={() => setSelectedHotspot(isSelected ? null : spot)}
                        className={`relative group p-2.5 rounded-full border transition-all duration-300 ${
                          isSelected
                            ? 'bg-white text-black border-emerald-400 scale-125 shadow-[0_0_25px_#ffffff]'
                            : 'bg-black/80 hover:bg-emerald-500 text-emerald-400 hover:text-black border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.5)]'
                        }`}
                        aria-label={spot.title}
                      >
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 group-hover:bg-black block animate-pulse" />
                        <span className="absolute -inset-2 rounded-full border border-emerald-400/50 animate-ping opacity-60 pointer-events-none" />
                      </button>

                      {/* Floating Micro Label */}
                      <div className="hidden sm:block absolute left-full ml-3 top-1/2 -translate-y-1/2 whitespace-nowrap px-3 py-1 rounded-lg bg-black/80 backdrop-blur-md border border-emerald-500/30 text-[11px] font-mono-tech text-white pointer-events-none">
                        {spot.title}
                      </div>
                    </div>
                  );
                })}

              {/* Hotspot Drawer / Detail Popover */}
              <AnimatePresence>
                {selectedHotspot && (
                  <motion.div
                    initial={{ opacity: 0, y: 20, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 20, scale: 0.95 }}
                    className="absolute bottom-6 left-6 right-6 sm:left-auto sm:right-6 sm:w-96 p-5 rounded-2xl bg-black/90 backdrop-blur-xl border border-emerald-400 shadow-2xl z-30"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="text-[10px] font-mono-tech uppercase tracking-widest text-emerald-400">
                          {selectedHotspot.category} SPECIFICATION
                        </span>
                        <h4 className="text-lg font-bold text-white mt-0.5">
                          {selectedHotspot.title}
                        </h4>
                        <div className="text-xs text-emerald-300 font-medium">
                          {selectedHotspot.subtitle}
                        </div>
                      </div>
                      <button
                        onClick={() => setSelectedHotspot(null)}
                        className="p-1 rounded-lg bg-white/10 text-gray-400 hover:text-white"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <p className="mt-3 text-xs text-gray-300 leading-relaxed">
                      {selectedHotspot.description}
                    </p>

                    <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-[10px] text-gray-400 font-mono-tech">
                      <span>VERIFIED VIP SUITE SPEC</span>
                      <span className="text-emerald-400">KHALID NASIR FLEET</span>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </AnimatePresence>

          {/* Bottom Showcase Pillars Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-emerald-950/80 bg-neutral-950/90 border-t border-emerald-950/80 p-5">
            <div className="p-3 text-center sm:text-left">
              <div className="text-emerald-400 font-bold text-sm uppercase tracking-wide flex items-center justify-center sm:justify-start gap-2">
                <Armchair className="w-4 h-4" />
                <span>COMFORTABLE SEATING</span>
              </div>
              <p className="text-xs text-gray-400 mt-1">
                Zero-gravity 160° reclining leather seats with private leg extensions.
              </p>
            </div>

            <div className="p-3 text-center sm:text-left">
              <div className="text-emerald-400 font-bold text-sm uppercase tracking-wide flex items-center justify-center sm:justify-start gap-2">
                <Wifi className="w-4 h-4" />
                <span>SPACIOUS INTERIOR</span>
              </div>
              <p className="text-xs text-gray-400 mt-1">
                Generous ceiling clearance, wide aisles, and climate-controlled cabins.
              </p>
            </div>

            <div className="p-3 text-center sm:text-left">
              <div className="text-emerald-400 font-bold text-sm uppercase tracking-wide flex items-center justify-center sm:justify-start gap-2">
                <Zap className="w-4 h-4" />
                <span>MODERN TRAVEL EXPERIENCE</span>
              </div>
              <p className="text-xs text-gray-400 mt-1">
                Starlink satellite Wi-Fi, USB-C ports, and hygienic comfort packs.
              </p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
