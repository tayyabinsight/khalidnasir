import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Bus, MapPin, Gauge, Shield, Wifi, Navigation2, CheckCircle, Clock, Zap, ArrowRight } from 'lucide-react';

export const LiveJourneyVisual: React.FC = () => {
  const [activeProgress, setActiveProgress] = useState(48); // percentage along route
  const [speed, setSpeed] = useState(96);

  // Subtle speed fluctuation
  useEffect(() => {
    const interval = setInterval(() => {
      setSpeed(94 + Math.floor(Math.random() * 6));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const journeyStops = [
    { name: 'Karachi Terminal', time: '08:00 PM', status: 'completed', km: '0 km' },
    { name: 'Hyderabad Bypass', time: '10:15 PM', status: 'completed', km: '165 km' },
    { name: 'Sukkur Oasis Rest Area', time: '02:30 AM', status: 'current', km: '490 km' },
    { name: 'Multan Interchange', time: '06:45 AM', status: 'upcoming', km: '910 km' },
    { name: 'Faisalabad Link', time: '09:30 AM', status: 'upcoming', km: '1,150 km' },
    { name: 'Rawalpindi Central', time: '01:45 PM', status: 'upcoming', km: '1,410 km' },
  ];

  return (
    <section id="live-status" className="relative py-24 bg-[#030704] text-white overflow-hidden border-t border-emerald-950/40">
      {/* Ambient background light */}
      <div className="absolute top-1/2 left-1/3 w-[50vw] h-[50vh] bg-emerald-950/20 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Title */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 text-xs font-mono-tech uppercase tracking-widest mb-3">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>REAL-TIME MOTORWAY TELEMETRY</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight uppercase font-heading">
              On The Road
            </h2>
            <p className="text-sm sm:text-base text-gray-300 mt-2">
              Active journey monitoring for <strong className="text-emerald-400">Karachi ⇄ Rawalpindi Express (Coach #PE-102)</strong>
            </p>
          </div>

          <div className="mt-4 md:mt-0 flex items-center gap-3">
            <div className="px-4 py-2 rounded-xl bg-emerald-950/60 border border-emerald-500/30 flex items-center gap-2 text-xs font-mono-tech">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_8px_#10b981]" />
              <span className="text-emerald-300 font-bold uppercase">STATUS: 🟢 ON TIME</span>
            </div>
          </div>
        </div>

        {/* Futuristic Journey Console Card */}
        <div className="glass-panel-glow rounded-3xl p-6 sm:p-10 border border-emerald-500/30 shadow-2xl relative overflow-hidden">
          
          {/* Header Telemetry Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pb-8 border-b border-emerald-950/70 text-center sm:text-left">
            <div className="p-3 rounded-2xl bg-black/40 border border-white/5">
              <div className="text-[10px] font-mono-tech uppercase text-gray-400">Active Speed</div>
              <div className="text-xl sm:text-2xl font-extrabold text-emerald-400 font-mono-tech mt-0.5 flex items-center justify-center sm:justify-start gap-2">
                <Gauge className="w-5 h-5 text-emerald-400" />
                <span>{speed} km/h</span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-black/40 border border-white/5">
              <div className="text-[10px] font-mono-tech uppercase text-gray-400">Departure Time</div>
              <div className="text-xl sm:text-2xl font-extrabold text-white font-mono-tech mt-0.5 flex items-center justify-center sm:justify-start gap-2">
                <Clock className="w-5 h-5 text-emerald-400" />
                <span>08:00 PM</span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-black/40 border border-white/5">
              <div className="text-[10px] font-mono-tech uppercase text-gray-400">Next Planned Halt</div>
              <div className="text-sm sm:text-base font-bold text-emerald-300 truncate mt-1">
                Sukkur Oasis
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-black/40 border border-white/5">
              <div className="text-[10px] font-mono-tech uppercase text-gray-400">Onboard Starlink</div>
              <div className="text-xl sm:text-2xl font-extrabold text-white font-mono-tech mt-0.5 flex items-center justify-center sm:justify-start gap-2">
                <Wifi className="w-5 h-5 text-emerald-400" />
                <span>152 Mbps</span>
              </div>
            </div>
          </div>

          {/* Route Progress Visualizer */}
          <div className="mt-10">
            <div className="flex items-center justify-between text-xs font-mono-tech text-gray-300 mb-4">
              <span className="text-emerald-400 font-bold uppercase">KARACHI CENTRAL</span>
              <span className="text-gray-400">490 / 1,410 KM COMPLETED</span>
              <span className="text-white font-bold uppercase">RAWALPINDI TERMINAL</span>
            </div>

            {/* Progress track */}
            <div className="relative w-full h-3 bg-neutral-900 rounded-full border border-emerald-950 overflow-visible">
              {/* Glowing filled track */}
              <div
                className="h-full rounded-full bg-gradient-to-r from-emerald-700 via-emerald-500 to-emerald-400 shadow-[0_0_15px_#10b981]"
                style={{ width: `${activeProgress}%` }}
              />

              {/* Moving Bus Pin on Progress Track */}
              <motion.div
                animate={{ x: [-2, 2, -2] }}
                transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                className="absolute -top-4 -translate-x-1/2 z-20"
                style={{ left: `${activeProgress}%` }}
              >
                <div className="relative group cursor-pointer">
                  <div className="px-3 py-1 rounded-lg bg-emerald-500 text-black font-extrabold text-[11px] font-mono-tech flex items-center gap-1.5 shadow-[0_0_20px_#10b981]">
                    <Bus className="w-4 h-4" />
                    <span>PE-102</span>
                  </div>
                  {/* Ping effect */}
                  <div className="absolute -inset-1 rounded-lg bg-emerald-400 blur-sm opacity-50 animate-pulse -z-10" />
                </div>
              </motion.div>
            </div>

            {/* Horizontal Stops Nodes */}
            <div className="mt-8 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
              {journeyStops.map((stop, idx) => (
                <div
                  key={stop.name}
                  className={`p-3.5 rounded-2xl border transition-all ${
                    stop.status === 'completed'
                      ? 'bg-emerald-950/40 border-emerald-500/40 text-gray-200'
                      : stop.status === 'current'
                      ? 'bg-emerald-500/20 border-emerald-400 text-white shadow-[0_0_20px_rgba(16,185,129,0.3)]'
                      : 'bg-black/30 border-white/5 text-gray-400'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] font-mono-tech">
                    <span className="text-gray-400">{stop.km}</span>
                    {stop.status === 'completed' && <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />}
                    {stop.status === 'current' && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />}
                  </div>

                  <div className="text-xs font-bold mt-1 truncate">
                    {stop.name}
                  </div>

                  <div className="text-[11px] font-mono-tech mt-1 text-emerald-400">
                    {stop.time}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Footer note */}
          <div className="mt-8 pt-6 border-t border-emerald-950/60 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-400 font-mono-tech">
            <span className="flex items-center gap-2 text-emerald-400">
              <Shield className="w-4 h-4 text-emerald-400" />
              Direct supervision under Khalid Nasir Operations Control
            </span>
            <span className="text-gray-500">
              GPS Refresh: Every 5s
            </span>
          </div>

        </div>
      </div>
    </section>
  );
};
