import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  Armchair, 
  Activity, 
  CreditCard, 
  Check, 
  Clock, 
  ShieldCheck, 
  ChevronRight, 
  ArrowRight,
  Radio,
  Wifi,
  Smartphone,
  Wallet,
  Building
} from 'lucide-react';

interface FeaturesSectionProps {
  onOpenBooking: () => void;
}

export const FeaturesSection: React.FC<FeaturesSectionProps> = ({ onOpenBooking }) => {
  // 1. Seat illumination loop for "CHOOSE YOUR SEAT"
  const [illuminatedSeat, setIlluminatedSeat] = useState<number>(0);
  useEffect(() => {
    const interval = setInterval(() => {
      setIlluminatedSeat((prev) => (prev + 1) % 9);
    }, 900);
    return () => clearInterval(interval);
  }, []);

  // 2. Trip Status Switcher for "TRAVEL WITH CONFIDENCE"
  const tripStatuses = [
    { label: 'ON TIME', color: 'text-emerald-400', badge: 'bg-emerald-500/20 border-emerald-500/40', eta: '18:00 PKT', loc: 'Karachi Central Lounge' },
    { label: 'BOARDING', color: 'text-amber-300', badge: 'bg-amber-500/20 border-amber-500/40', eta: 'Gate 02 Open', loc: 'Platform 1A - Express 101' },
    { label: 'DEPARTING', color: 'text-emerald-400', badge: 'bg-emerald-500/20 border-emerald-500/40', eta: 'Leaving on schedule', loc: 'Super Highway Toll Plaza' },
    { label: 'ON THE WAY', color: 'text-emerald-300', badge: 'bg-emerald-500/30 border-emerald-400/50', eta: 'Cruising at 100 km/h', loc: 'M-5 Motorway (Sukkur-Multan)' },
  ];
  const [statusIndex, setStatusIndex] = useState(0);
  useEffect(() => {
    const statusInterval = setInterval(() => {
      setStatusIndex((prev) => (prev + 1) % tripStatuses.length);
    }, 2400);
    return () => clearInterval(statusInterval);
  }, [tripStatuses.length]);

  // 3. Payment methods tab
  const paymentMethods = [
    { id: 'jazzcash', name: 'JazzCash', sub: 'Instant Mobile Wallet', color: 'from-red-600/30 to-black', icon: '⚡' },
    { id: 'easypaisa', name: 'Easypaisa', sub: 'Zero Transaction Fee', color: 'from-green-600/30 to-black', icon: '📱' },
    { id: 'bank', name: '1Link Bank Transfer', sub: 'Raast & All Pakistani Banks', color: 'from-blue-600/30 to-black', icon: '🏛️' },
    { id: 'cash', name: 'Terminal Cash', sub: 'Pay on Boarding / Counter', color: 'from-emerald-600/30 to-black', icon: '💵' },
  ];
  const [selectedPayment, setSelectedPayment] = useState('jazzcash');

  return (
    <section id="features" className="relative py-24 bg-[#020503] text-white overflow-hidden border-t border-emerald-950/40">
      {/* Background Glow */}
      <div className="absolute top-1/3 left-10 w-[45vw] h-[45vh] bg-emerald-950/20 rounded-full blur-[150px] pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-[40vw] h-[40vh] bg-emerald-900/15 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-950/70 border border-emerald-500/30 text-emerald-400 text-xs font-mono-tech uppercase tracking-widest mb-4"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>ENGINEERED FOR SUPREME TRAVEL</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white uppercase font-heading"
          >
            The Future of <br className="sm:hidden" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-emerald-300 to-white">
              Highway Travel
            </span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="mt-4 text-sm sm:text-base text-gray-300"
          >
            Four pillars of uncompromising quality redefining passenger experience across Pakistan.
          </motion.p>
        </div>

        {/* 4 Large Interactive Panels Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          {/* PANEL 1: EASY BOOKING */}
          <motion.div
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="glass-panel-glow rounded-3xl p-6 sm:p-8 border border-emerald-500/30 relative overflow-hidden flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono-tech uppercase tracking-widest text-emerald-400">
                  FEATURE 01
                </span>
                <span className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                  <Smartphone className="w-5 h-5" />
                </span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-extrabold text-white uppercase font-heading mt-3">
                Easy Booking
              </h3>
              <p className="text-sm sm:text-base text-emerald-300 font-medium mt-1">
                Your seat is just a few clicks away.
              </p>
              <p className="text-xs sm:text-sm text-gray-400 mt-2 leading-relaxed">
                Select your departure, choose your preferred suite, and receive instant digital tickets via SMS and WhatsApp in under 60 seconds.
              </p>
            </div>

            {/* Interactive Live Mini Booking Simulation */}
            <div className="mt-6 p-4 rounded-2xl bg-black/60 border border-emerald-500/20">
              <div className="flex items-center justify-between text-xs text-gray-300 pb-3 border-b border-white/10">
                <span className="text-emerald-400 font-mono-tech">EXPRESS CHECKOUT FLOW</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300">Live Preview</span>
              </div>

              <div className="mt-3 flex items-center justify-between gap-2">
                <div className="flex-1 p-2 rounded-xl bg-neutral-900/80 border border-white/5 text-center">
                  <div className="text-[9px] uppercase text-gray-400">1. Route</div>
                  <div className="text-xs font-bold text-white mt-0.5">Karachi → RWP</div>
                </div>
                <ChevronRight className="w-4 h-4 text-emerald-400 shrink-0" />
                <div className="flex-1 p-2 rounded-xl bg-neutral-900/80 border border-white/5 text-center">
                  <div className="text-[9px] uppercase text-gray-400">2. Fleet</div>
                  <div className="text-xs font-bold text-emerald-400 mt-0.5">Royal VIP</div>
                </div>
                <ChevronRight className="w-4 h-4 text-emerald-400 shrink-0" />
                <div className="flex-1 p-2 rounded-xl bg-neutral-900/80 border border-white/5 text-center">
                  <div className="text-[9px] uppercase text-gray-400">3. Pass</div>
                  <div className="text-xs font-bold text-white mt-0.5">E-Ticket</div>
                </div>
              </div>

              <button
                onClick={onOpenBooking}
                className="w-full mt-3 py-2.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors"
              >
                <span>Launch Interactive Booking</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </motion.div>

          {/* PANEL 2: CHOOSE YOUR SEAT (Illuminating Bus Seats) */}
          <motion.div
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="glass-panel-glow rounded-3xl p-6 sm:p-8 border border-emerald-500/30 relative overflow-hidden flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono-tech uppercase tracking-widest text-emerald-400">
                  FEATURE 02
                </span>
                <span className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                  <Armchair className="w-5 h-5" />
                </span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-extrabold text-white uppercase font-heading mt-3">
                Choose Your Seat
              </h3>
              <p className="text-sm sm:text-base text-emerald-300 font-medium mt-1">
                Your journey. Your seat.
              </p>
              <p className="text-xs sm:text-sm text-gray-400 mt-2 leading-relaxed">
                Enjoy 1+2 VIP layout offering standalone solo suites for complete privacy or paired recliners for families and companions.
              </p>
            </div>

            {/* Illuminated Seat Matrix Visualizer */}
            <div className="mt-6 p-4 rounded-2xl bg-black/60 border border-emerald-500/20">
              <div className="flex items-center justify-between text-xs text-gray-300 pb-2 border-b border-white/10">
                <span className="text-[11px] font-mono-tech text-emerald-400">1+2 VIP CABIN MATRIX</span>
                <span className="text-[10px] text-gray-400">Illuminating live</span>
              </div>

              {/* 3 Rows of Seats: 1 Solo (Left), Aisle, 2 Paired (Right) */}
              <div className="mt-3 space-y-2.5">
                {[0, 1, 2].map((rowIdx) => (
                  <div key={rowIdx} className="flex items-center justify-between gap-3">
                    {/* Solo Left Seat */}
                    <div
                      className={`flex-1 p-2.5 rounded-xl border flex items-center justify-center gap-1.5 transition-all duration-300 ${
                        illuminatedSeat === rowIdx * 3
                          ? 'bg-emerald-500 text-black font-extrabold border-emerald-300 scale-105 shadow-[0_0_15px_#10b981]'
                          : 'bg-neutral-900/90 border-white/10 text-gray-300'
                      }`}
                    >
                      <Armchair className="w-3.5 h-3.5" />
                      <span className="text-xs font-mono-tech">{rowIdx + 1}A</span>
                    </div>

                    {/* Cabin Aisle Indicator */}
                    <div className="w-6 text-center text-[9px] font-mono-tech text-gray-600">
                      AISLE
                    </div>

                    {/* Paired Right Seats */}
                    <div className="flex-[2] flex gap-2">
                      <div
                        className={`flex-1 p-2.5 rounded-xl border flex items-center justify-center gap-1.5 transition-all duration-300 ${
                          illuminatedSeat === rowIdx * 3 + 1
                            ? 'bg-emerald-500 text-black font-extrabold border-emerald-300 scale-105 shadow-[0_0_15px_#10b981]'
                            : 'bg-neutral-900/90 border-white/10 text-gray-300'
                        }`}
                      >
                        <Armchair className="w-3.5 h-3.5" />
                        <span className="text-xs font-mono-tech">{rowIdx + 1}B</span>
                      </div>

                      <div
                        className={`flex-1 p-2.5 rounded-xl border flex items-center justify-center gap-1.5 transition-all duration-300 ${
                          illuminatedSeat === rowIdx * 3 + 2
                            ? 'bg-emerald-500 text-black font-extrabold border-emerald-300 scale-105 shadow-[0_0_15px_#10b981]'
                            : 'bg-neutral-900/90 border-white/10 text-gray-300'
                        }`}
                      >
                        <Armchair className="w-3.5 h-3.5" />
                        <span className="text-xs font-mono-tech">{rowIdx + 1}C</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* PANEL 3: TRAVEL WITH CONFIDENCE (Live Trip Status Switcher) */}
          <motion.div
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="glass-panel-glow rounded-3xl p-6 sm:p-8 border border-emerald-500/30 relative overflow-hidden flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono-tech uppercase tracking-widest text-emerald-400">
                  FEATURE 03
                </span>
                <span className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                  <Activity className="w-5 h-5" />
                </span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-extrabold text-white uppercase font-heading mt-3">
                Travel with Confidence
              </h3>
              <p className="text-sm sm:text-base text-emerald-300 font-medium mt-1">
                Stay informed throughout your journey.
              </p>
              <p className="text-xs sm:text-sm text-gray-400 mt-2 leading-relaxed">
                Live GPS telemetry feeds, real-time speed monitoring, and arrival time estimates keep loved ones assured 24/7.
              </p>
            </div>

            {/* Dynamic Animated Status Display */}
            <div className="mt-6 p-4 rounded-2xl bg-black/60 border border-emerald-500/20">
              <div className="flex items-center justify-between text-xs pb-3 border-b border-white/10">
                <span className="text-gray-400 font-mono-tech">COACH TELEMETRY #PE-102</span>
                <span className="flex items-center gap-1 text-emerald-400 text-[10px]">
                  <Radio className="w-3 h-3 animate-pulse" />
                  SATELLITE ACTIVE
                </span>
              </div>

              <AnimatePresence mode="wait">
                <motion.div
                  key={tripStatuses[statusIndex].label}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3 }}
                  className="mt-3 flex items-center justify-between p-3 rounded-xl bg-neutral-900 border border-white/10"
                >
                  <div>
                    <div className="text-[10px] uppercase text-gray-400">Current Status</div>
                    <div className={`text-lg font-extrabold tracking-wider ${tripStatuses[statusIndex].color} font-mono-tech`}>
                      {tripStatuses[statusIndex].label}
                    </div>
                    <div className="text-[11px] text-gray-300 mt-0.5">
                      {tripStatuses[statusIndex].loc}
                    </div>
                  </div>

                  <div className="text-right">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold border ${tripStatuses[statusIndex].badge}`}>
                      {tripStatuses[statusIndex].eta}
                    </span>
                  </div>
                </motion.div>
              </AnimatePresence>

              {/* Status progression bar */}
              <div className="mt-3 grid grid-cols-4 gap-1.5">
                {tripStatuses.map((s, idx) => (
                  <div
                    key={s.label}
                    className={`h-1.5 rounded-full transition-all duration-300 ${
                      idx <= statusIndex ? 'bg-emerald-400 shadow-[0_0_8px_#10b981]' : 'bg-neutral-800'
                    }`}
                  />
                ))}
              </div>
            </div>
          </motion.div>

          {/* PANEL 4: MULTIPLE PAYMENT OPTIONS */}
          <motion.div
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="glass-panel-glow rounded-3xl p-6 sm:p-8 border border-emerald-500/30 relative overflow-hidden flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono-tech uppercase tracking-widest text-emerald-400">
                  FEATURE 04
                </span>
                <span className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                  <Wallet className="w-5 h-5" />
                </span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-extrabold text-white uppercase font-heading mt-3">
                Multiple Payment Options
              </h3>
              <p className="text-sm sm:text-base text-emerald-300 font-medium mt-1">
                Seamless digital & cash checkouts.
              </p>
              <p className="text-xs sm:text-sm text-gray-400 mt-2 leading-relaxed">
                Pay effortlessly via Pakistan's leading digital wallets, Raast bank transfer, or cash on counter before boarding.
              </p>
            </div>

            {/* Interactive Payment Badge Selector */}
            <div className="mt-6 space-y-2">
              <div className="grid grid-cols-2 gap-2">
                {paymentMethods.map((pm) => (
                  <button
                    key={pm.id}
                    onClick={() => setSelectedPayment(pm.id)}
                    className={`p-3 rounded-2xl border text-left transition-all duration-300 flex items-center gap-2.5 ${
                      selectedPayment === pm.id
                        ? 'bg-gradient-to-r ' + pm.color + ' border-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.3)] scale-[1.02]'
                        : 'bg-black/50 border-white/10 hover:border-emerald-500/30'
                    }`}
                  >
                    <span className="text-xl shrink-0">{pm.icon}</span>
                    <div className="overflow-hidden">
                      <div className="text-xs font-bold text-white truncate">{pm.name}</div>
                      <div className="text-[10px] text-gray-400 truncate">{pm.sub}</div>
                    </div>
                  </button>
                ))}
              </div>

              <div className="p-2.5 rounded-xl bg-black/40 border border-emerald-950/60 flex items-center justify-between text-[11px] text-gray-400">
                <span className="flex items-center gap-1 text-emerald-400">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  SSL 256-Bit Encrypted
                </span>
                <span className="text-gray-500">Demo Prototype</span>
              </div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};
