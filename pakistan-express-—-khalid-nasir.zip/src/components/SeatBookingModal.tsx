import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Check, Bus, Armchair, QrCode, Calendar, MapPin, Users, ShieldCheck, ArrowRight, ArrowLeft, Printer, Sparkles } from 'lucide-react';
import { CITIES, SEAT_MAP, POPULAR_ROUTES } from '../data/mockData';
import { RouteItem, Seat } from '../types';

interface SeatBookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialParams?: {
    from: string;
    to: string;
    date: string;
    passengers: number;
  };
  initialRoute?: RouteItem | null;
}

export const SeatBookingModal: React.FC<SeatBookingModalProps> = ({
  isOpen,
  onClose,
  initialParams,
  initialRoute,
}) => {
  const [step, setStep] = useState<number>(1);
  const [fromCity, setFromCity] = useState(initialRoute?.from || initialParams?.from || 'Karachi');
  const [toCity, setToCity] = useState(initialRoute?.to || initialParams?.to || 'Rawalpindi');
  const [travelDate, setTravelDate] = useState(initialParams?.date || 'Today, Aug 18');
  const [busClass, setBusClass] = useState<'Royal Executive' | 'VIP Sleeper'>('Royal Executive');
  const [selectedSeats, setSelectedSeats] = useState<string[]>(['1A']);
  const [passengerName, setPassengerName] = useState('Hamza Ali Khan');
  const [passengerPhone, setPassengerPhone] = useState('0300-1234567');
  const [passengerCNIC, setPassengerCNIC] = useState('42101-1234567-1');
  const [paymentMethod, setPaymentMethod] = useState<'JazzCash' | 'Easypaisa' | '1Link' | 'Cash'>('JazzCash');
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [bookingConfirmed, setBookingConfirmed] = useState(false);

  if (!isOpen) return null;

  const toggleSeat = (seat: Seat) => {
    if (seat.isBooked) return;
    if (selectedSeats.includes(seat.number)) {
      setSelectedSeats(selectedSeats.filter((s) => s !== seat.number));
    } else {
      if (selectedSeats.length < 4) {
        setSelectedSeats([...selectedSeats, seat.number]);
      }
    }
  };

  const getSeatPrice = () => (busClass === 'VIP Sleeper' ? 7500 : 6200);
  const totalAmount = getSeatPrice() * Math.max(selectedSeats.length, 1);

  const handleConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    setBookingConfirmed(true);
    setStep(4);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/85 backdrop-blur-xl">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-2xl bg-[#060a08] border border-emerald-500/40 rounded-3xl p-6 sm:p-8 shadow-[0_25px_80px_rgba(0,0,0,0.95)] text-white max-h-[90vh] overflow-y-auto"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 rounded-full bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 pb-5 border-b border-emerald-950/80">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-950 flex items-center justify-center border border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.4)]">
            <Bus className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-bold uppercase tracking-wide font-heading">
              Reserve Your Seat
            </h3>
            <p className="text-xs text-emerald-400 font-mono-tech">
              Pakistan Express — Khalid Nasir VIP Reservation
            </p>
          </div>
        </div>

        {/* Multi-step Flow */}
        {!bookingConfirmed ? (
          <div className="mt-6 space-y-6">
            {/* Step Indicators */}
            <div className="flex items-center justify-between text-xs font-mono-tech pb-3 border-b border-white/10">
              <span className={step >= 1 ? 'text-emerald-400 font-bold' : 'text-gray-500'}>1. ROUTE & DATE</span>
              <span className="text-gray-600">→</span>
              <span className={step >= 2 ? 'text-emerald-400 font-bold' : 'text-gray-500'}>2. SELECT SEATS</span>
              <span className="text-gray-600">→</span>
              <span className={step >= 3 ? 'text-emerald-400 font-bold' : 'text-gray-500'}>3. PASSENGER & PAY</span>
            </div>

            {/* STEP 1: ROUTE & DATE */}
            {step === 1 && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-3.5 rounded-2xl bg-black/60 border border-white/10">
                    <label className="block text-[10px] font-mono-tech uppercase text-emerald-400 font-bold">
                      FROM CITY
                    </label>
                    <select
                      value={fromCity}
                      onChange={(e) => setFromCity(e.target.value)}
                      className="w-full mt-1 bg-transparent text-white font-semibold text-sm focus:outline-none"
                    >
                      {CITIES.map((c) => (
                        <option key={c} value={c} className="bg-neutral-900 text-white">{c}</option>
                      ))}
                    </select>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-black/60 border border-white/10">
                    <label className="block text-[10px] font-mono-tech uppercase text-emerald-400 font-bold">
                      TO DESTINATION
                    </label>
                    <select
                      value={toCity}
                      onChange={(e) => setToCity(e.target.value)}
                      className="w-full mt-1 bg-transparent text-white font-semibold text-sm focus:outline-none"
                    >
                      {CITIES.filter((c) => c !== fromCity).map((c) => (
                        <option key={c} value={c} className="bg-neutral-900 text-white">{c}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-3.5 rounded-2xl bg-black/60 border border-white/10">
                    <label className="block text-[10px] font-mono-tech uppercase text-emerald-400 font-bold">
                      DEPARTURE DATE
                    </label>
                    <select
                      value={travelDate}
                      onChange={(e) => setTravelDate(e.target.value)}
                      className="w-full mt-1 bg-transparent text-white font-semibold text-sm focus:outline-none"
                    >
                      <option value="Today, Aug 18" className="bg-neutral-900 text-white">Today, Aug 18</option>
                      <option value="Tomorrow, Aug 19" className="bg-neutral-900 text-white">Tomorrow, Aug 19</option>
                      <option value="Wednesday, Aug 20" className="bg-neutral-900 text-white">Wednesday, Aug 20</option>
                    </select>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-black/60 border border-white/10">
                    <label className="block text-[10px] font-mono-tech uppercase text-emerald-400 font-bold">
                      TRAVEL CLASS
                    </label>
                    <select
                      value={busClass}
                      onChange={(e) => setBusClass(e.target.value as any)}
                      className="w-full mt-1 bg-transparent text-white font-semibold text-sm focus:outline-none"
                    >
                      <option value="Royal Executive" className="bg-neutral-900 text-white">Royal Executive (1+2 Recliners)</option>
                      <option value="VIP Sleeper" className="bg-neutral-900 text-white">VIP Sleeper (180° Lie-Flat)</option>
                    </select>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/20 text-xs text-gray-300 flex items-center justify-between">
                  <span>Estimated Motorway Travel Time:</span>
                  <span className="font-bold text-emerald-400 font-mono-tech">18h 30m (Direct Fast-Track)</span>
                </div>

                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-emerald-400 text-black font-extrabold text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(16,185,129,0.4)] flex items-center justify-center gap-2"
                >
                  <span>Continue to Seat Selection</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* STEP 2: SEAT SELECTION */}
            {step === 2 && (
              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-base font-bold text-white">Choose Your 1+2 Recliner Seat</h4>
                    <p className="text-xs text-gray-400">Selected: <strong className="text-emerald-400">{selectedSeats.join(', ') || 'None'}</strong></p>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] uppercase text-gray-400">Total Fare</div>
                    <div className="text-base font-bold text-emerald-400 font-mono-tech">PKR {totalAmount.toLocaleString()}</div>
                  </div>
                </div>

                {/* Interactive Seat Matrix */}
                <div className="p-4 rounded-2xl bg-black/60 border border-emerald-500/20 max-w-md mx-auto">
                  <div className="flex justify-between items-center pb-2 mb-3 border-b border-white/10 text-[10px] font-mono-tech text-gray-400">
                    <span>FRONT CABIN</span>
                    <span className="text-emerald-400">WIFI ROUTER</span>
                  </div>

                  <div className="space-y-2">
                    {[1, 2, 3, 4, 5, 6].map((row) => {
                      const rowSeats = SEAT_MAP.filter((s) => s.row === row);
                      const seatA = rowSeats.find((s) => s.col === 1);
                      const seatB = rowSeats.find((s) => s.col === 2);
                      const seatC = rowSeats.find((s) => s.col === 3);

                      return (
                        <div key={row} className="flex items-center justify-between gap-2">
                          {/* Solo Seat A */}
                          {seatA && (
                            <button
                              type="button"
                              onClick={() => toggleSeat(seatA)}
                              disabled={seatA.isBooked}
                              className={`flex-1 p-2 rounded-xl border flex items-center justify-center gap-1 transition-all ${
                                selectedSeats.includes(seatA.number)
                                  ? 'bg-emerald-500 text-black font-extrabold border-emerald-300 shadow-[0_0_12px_#10b981]'
                                  : seatA.isBooked
                                  ? 'bg-neutral-900/30 border-neutral-800 text-neutral-600 cursor-not-allowed'
                                  : 'bg-neutral-900 border-white/10 hover:border-emerald-500 text-gray-300'
                              }`}
                            >
                              <Armchair className="w-3.5 h-3.5" />
                              <span className="text-xs font-mono-tech">{seatA.number}</span>
                            </button>
                          )}

                          <div className="w-4 text-center text-[7px] text-gray-600">AISLE</div>

                          {/* Double Seats B & C */}
                          <div className="flex-[2] flex gap-2">
                            {seatB && (
                              <button
                                type="button"
                                onClick={() => toggleSeat(seatB)}
                                disabled={seatB.isBooked}
                                className={`flex-1 p-2 rounded-xl border flex items-center justify-center gap-1 transition-all ${
                                  selectedSeats.includes(seatB.number)
                                    ? 'bg-emerald-500 text-black font-extrabold border-emerald-300 shadow-[0_0_12px_#10b981]'
                                    : seatB.isBooked
                                    ? 'bg-neutral-900/30 border-neutral-800 text-neutral-600 cursor-not-allowed'
                                    : 'bg-neutral-900 border-white/10 hover:border-emerald-500 text-gray-300'
                                }`}
                              >
                                <Armchair className="w-3.5 h-3.5" />
                                <span className="text-xs font-mono-tech">{seatB.number}</span>
                              </button>
                            )}
                            {seatC && (
                              <button
                                type="button"
                                onClick={() => toggleSeat(seatC)}
                                disabled={seatC.isBooked}
                                className={`flex-1 p-2 rounded-xl border flex items-center justify-center gap-1 transition-all ${
                                  selectedSeats.includes(seatC.number)
                                    ? 'bg-emerald-500 text-black font-extrabold border-emerald-300 shadow-[0_0_12px_#10b981]'
                                    : seatC.isBooked
                                    ? 'bg-neutral-900/30 border-neutral-800 text-neutral-600 cursor-not-allowed'
                                    : 'bg-neutral-900 border-white/10 hover:border-emerald-500 text-gray-300'
                                }`}
                              >
                                <Armchair className="w-3.5 h-3.5" />
                                <span className="text-xs font-mono-tech">{seatC.number}</span>
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="px-4 py-2.5 rounded-xl border border-white/10 text-xs font-bold text-gray-300"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setStep(3)}
                    disabled={selectedSeats.length === 0}
                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-400 text-black font-extrabold text-xs uppercase tracking-wider disabled:opacity-40"
                  >
                    Continue to Details
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: PASSENGER DETAILS & PAYMENT */}
            {step === 3 && (
              <form onSubmit={handleConfirm} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-3.5 rounded-2xl bg-black/60 border border-white/10">
                    <label className="block text-[10px] font-mono-tech uppercase text-emerald-400 font-bold">
                      PASSENGER FULL NAME
                    </label>
                    <input
                      type="text"
                      required
                      value={passengerName}
                      onChange={(e) => setPassengerName(e.target.value)}
                      className="w-full mt-1 bg-transparent text-white font-semibold text-sm focus:outline-none"
                      placeholder="e.g. Hamza Ali"
                    />
                  </div>

                  <div className="p-3.5 rounded-2xl bg-black/60 border border-white/10">
                    <label className="block text-[10px] font-mono-tech uppercase text-emerald-400 font-bold">
                      WHATSAPP / MOBILE NUMBER
                    </label>
                    <input
                      type="text"
                      required
                      value={passengerPhone}
                      onChange={(e) => setPassengerPhone(e.target.value)}
                      className="w-full mt-1 bg-transparent text-white font-semibold text-sm focus:outline-none"
                      placeholder="0300-1234567"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-3.5 rounded-2xl bg-black/60 border border-white/10">
                    <label className="block text-[10px] font-mono-tech uppercase text-emerald-400 font-bold">
                      CNIC NUMBER (FOR SECURITY)
                    </label>
                    <input
                      type="text"
                      value={passengerCNIC}
                      onChange={(e) => setPassengerCNIC(e.target.value)}
                      className="w-full mt-1 bg-transparent text-white font-semibold text-sm focus:outline-none"
                      placeholder="42101-XXXXXXX-X"
                    />
                  </div>

                  <div className="p-3.5 rounded-2xl bg-black/60 border border-white/10">
                    <label className="block text-[10px] font-mono-tech uppercase text-emerald-400 font-bold">
                      PAYMENT METHOD
                    </label>
                    <select
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value as any)}
                      className="w-full mt-1 bg-transparent text-white font-semibold text-sm focus:outline-none cursor-pointer"
                    >
                      <option value="JazzCash" className="bg-neutral-900 text-white">JazzCash Mobile Wallet</option>
                      <option value="Easypaisa" className="bg-neutral-900 text-white">Easypaisa Wallet</option>
                      <option value="1Link" className="bg-neutral-900 text-white">1Link / Raast Online Bank</option>
                      <option value="Cash" className="bg-neutral-900 text-white">Cash on Terminal Counter</option>
                    </select>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-black/60 border border-emerald-500/30 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-gray-400">Total Payable Amount:</span>
                    <div className="text-lg font-extrabold text-emerald-400 font-mono-tech">
                      PKR {totalAmount.toLocaleString()}
                    </div>
                  </div>
                  <div className="text-right text-[11px] text-gray-400 font-mono-tech">
                    {selectedSeats.length} Seat(s) • {busClass}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="px-4 py-2.5 rounded-xl border border-white/10 text-xs font-bold text-gray-300"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-3 rounded-xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-emerald-400 text-black font-extrabold text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(16,185,129,0.5)] flex items-center gap-2"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Confirm & Generate E-Pass</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        ) : (
          /* STEP 4: BOARDING PASS COMPLETE */
          <div className="mt-6 space-y-6 text-center">
            <div className="p-6 rounded-3xl bg-gradient-to-br from-neutral-900 via-black to-[#06150a] border border-emerald-400 shadow-2xl text-left relative overflow-hidden">
              <div className="flex items-center justify-between pb-4 border-b border-emerald-950">
                <div>
                  <div className="text-[10px] font-mono-tech uppercase tracking-widest text-emerald-400">
                    PAKISTAN EXPRESS • KHALID NASIR
                  </div>
                  <div className="text-2xl font-extrabold text-white uppercase font-heading">
                    {fromCity} → {toCity}
                  </div>
                </div>
                <div className="text-right">
                  <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-mono-tech font-bold">
                    PNR: PE-9912
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-4 border-b border-emerald-950 text-xs">
                <div>
                  <div className="text-gray-400 text-[10px] font-mono-tech uppercase">Passenger</div>
                  <div className="font-bold text-white mt-0.5">{passengerName}</div>
                </div>
                <div>
                  <div className="text-gray-400 text-[10px] font-mono-tech uppercase">Travel Date</div>
                  <div className="font-bold text-white mt-0.5">{travelDate}</div>
                </div>
                <div>
                  <div className="text-gray-400 text-[10px] font-mono-tech uppercase">Seat(s)</div>
                  <div className="font-bold text-emerald-400 font-mono-tech text-sm mt-0.5">{selectedSeats.join(', ')}</div>
                </div>
                <div>
                  <div className="text-gray-400 text-[10px] font-mono-tech uppercase">Total Fare</div>
                  <div className="font-bold text-white font-mono-tech mt-0.5">PKR {totalAmount.toLocaleString()}</div>
                </div>
              </div>

              <div className="mt-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-white text-black">
                    <QrCode className="w-10 h-10" />
                  </div>
                  <div className="text-xs text-gray-300 font-mono-tech">
                    <div className="text-emerald-400 font-bold">SMART BOARDING QR ACTIVE</div>
                    <div className="text-[10px] text-gray-400">Show to coach steward on boarding</div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => window.print()}
                  className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-gray-200 flex items-center gap-2 text-xs font-semibold"
                >
                  <Printer className="w-4 h-4 text-emerald-400" />
                  <span>Print Ticket</span>
                </button>
              </div>
            </div>

            <p className="text-xs text-emerald-400/90 font-mono-tech">
              A copy of your booking and SMS confirmation has been simulated for {passengerPhone}.
            </p>

            <button
              onClick={onClose}
              className="px-8 py-3 rounded-full bg-emerald-500 text-black font-extrabold text-xs uppercase tracking-wider hover:bg-emerald-400 transition-all"
            >
              Done
            </button>
          </div>
        )}

      </motion.div>
    </div>
  );
};
