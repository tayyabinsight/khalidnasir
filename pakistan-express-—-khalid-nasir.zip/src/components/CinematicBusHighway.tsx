import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { ASSETS } from '../data/mockData';

export const CinematicBusHighway: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Particles & ambient dust animation on canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || window.innerWidth);
    let height = (canvas.height = canvas.parentElement?.clientHeight || window.innerHeight);

    const handleResize = () => {
      if (!canvas || !canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = canvas.parentElement.clientHeight;
    };
    window.addEventListener('resize', handleResize);

    // Generate floating highway dust/spark particles
    const particleCount = 45;
    const particles = Array.from({ length: particleCount }).map(() => ({
      x: Math.random() * width,
      y: Math.random() * height,
      size: Math.random() * 2.5 + 0.5,
      speedX: -(Math.random() * 2.5 + 1.2), // moving left (highway speed)
      speedY: (Math.random() - 0.5) * 0.4,
      opacity: Math.random() * 0.7 + 0.2,
      color: Math.random() > 0.4 ? 'rgba(16, 185, 129,' : 'rgba(255, 255, 255,',
    }));

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw highway particles
      particles.forEach((p) => {
        p.x += p.speedX;
        p.y += p.speedY;

        if (p.x < -10) {
          p.x = width + 10;
          p.y = Math.random() * height;
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `${p.color} ${p.opacity})`;
        ctx.shadowBlur = 8;
        ctx.shadowColor = '#10b981';
        ctx.fill();
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none select-none">
      {/* Background Dark Sky & Night Mountains Silhouette */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#020503] via-[#040906] to-[#010302]" />

      {/* Atmospheric Emerald Nebula / Night Sky Glow */}
      <div className="absolute -top-[20%] left-1/4 w-[60vw] h-[60vh] bg-emerald-950/20 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute top-1/3 -right-20 w-[40vw] h-[50vh] bg-emerald-900/15 rounded-full blur-[120px] pointer-events-none" />

      {/* Distant Motorway Mountain Silhouette */}
      <div className="absolute bottom-[32%] inset-x-0 h-40 opacity-30">
        <svg viewBox="0 0 1440 240" fill="none" className="w-full h-full preserve-3d" preserveAspectRatio="none">
          <path
            d="M0 240L0 160L120 130L260 170L380 90L520 150L680 80L820 140L960 70L1120 130L1260 90L1440 160L1440 240Z"
            fill="#05120a"
          />
          <path
            d="M0 240L0 190L180 150L340 180L500 120L660 170L800 110L980 160L1180 120L1320 150L1440 180L1440 240Z"
            fill="#020804"
          />
        </svg>
      </div>

      {/* Passing Overhead Streetlights */}
      <div className="absolute bottom-[36%] inset-x-0 h-32 overflow-hidden">
        <motion.div
          animate={{ x: [1600, -400] }}
          transition={{ duration: 4.5, repeat: Infinity, ease: 'linear' }}
          className="absolute top-0 flex gap-[450px]"
        >
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="relative flex flex-col items-center">
              {/* Lamp head */}
              <div className="w-4 h-1.5 bg-amber-200/90 rounded-full shadow-[0_0_20px_#fde68a]" />
              {/* Lamp light cone casting down on road */}
              <div className="w-44 h-48 bg-gradient-to-b from-amber-200/20 via-amber-300/5 to-transparent blur-md -rotate-6 transform -translate-x-12" />
            </div>
          ))}
        </motion.div>
      </div>

      {/* The Asphalt Highway */}
      <div className="absolute bottom-0 inset-x-0 h-[38%] bg-gradient-to-t from-[#020302] via-[#070e0a] to-[#040a06] border-t border-emerald-950/60">
        {/* Wet road surface reflection highlight */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,rgba(16,185,129,0.18)_0%,transparent_70%)]" />

        {/* Perspective Road Markings (Continuous Highway Speed Motion) */}
        <div className="absolute top-[28%] inset-x-0 h-[4px] overflow-hidden flex items-center">
          <motion.div
            animate={{ x: [0, -280] }}
            transition={{ duration: 0.8, repeat: Infinity, ease: 'linear' }}
            className="flex gap-16 w-[300%]"
          >
            {Array.from({ length: 40 }).map((_, i) => (
              <div key={i} className="w-24 h-[2.5px] bg-emerald-400/60 rounded-full shadow-[0_0_8px_#10b981]" />
            ))}
          </motion.div>
        </div>

        {/* Center Dashed White Lines */}
        <div className="absolute top-[55%] inset-x-0 h-[6px] overflow-hidden flex items-center">
          <motion.div
            animate={{ x: [0, -320] }}
            transition={{ duration: 0.65, repeat: Infinity, ease: 'linear' }}
            className="flex gap-20 w-[300%]"
          >
            {Array.from({ length: 40 }).map((_, i) => (
              <div key={i} className="w-32 h-[3.5px] bg-white/80 rounded-full shadow-[0_0_12px_rgba(255,255,255,0.7)]" />
            ))}
          </motion.div>
        </div>

        {/* Road Edge Cat's Eyes (Reflective studs glowing emerald) */}
        <div className="absolute bottom-6 inset-x-0 h-2 overflow-hidden flex items-center">
          <motion.div
            animate={{ x: [0, -360] }}
            transition={{ duration: 0.55, repeat: Infinity, ease: 'linear' }}
            className="flex gap-28 w-[300%]"
          >
            {Array.from({ length: 30 }).map((_, i) => (
              <div key={i} className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_10px_#10b981]" />
            ))}
          </motion.div>
        </div>
      </div>

      {/* CINEMATIC REALISTIC BUS (Moving smoothly across the highway) */}
      <div className="absolute bottom-[16%] left-[4%] sm:left-[8%] lg:left-[12%] w-[85%] max-w-[850px] z-20">
        <motion.div
          animate={{
            y: [-3, 3, -2, 2, -3],
            x: [-6, 6, -3, 3, -6],
          }}
          transition={{
            duration: 5,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="relative group"
        >
          {/* Ground Neon Underglow */}
          <div className="absolute -bottom-8 left-10 right-16 h-14 bg-emerald-500/40 rounded-full blur-2xl transform scale-y-50 animate-pulse" />
          <div className="absolute -bottom-6 left-24 right-28 h-8 bg-white/20 rounded-full blur-xl" />

          {/* Forward Xenon Headlight Beams (Shooting forward across highway) */}
          <div className="absolute top-[52%] left-[82%] w-[55vw] max-w-[700px] h-[140px] pointer-events-none z-30 transform -rotate-1 origin-left">
            <div className="w-full h-full bg-gradient-to-r from-emerald-100/75 via-emerald-300/25 to-transparent blur-md clip-beam" />
            <div className="absolute top-1/3 left-0 w-full h-[40px] bg-gradient-to-r from-white/90 via-emerald-200/40 to-transparent blur-sm" />
            {/* Ground beam spotlight footprint */}
            <div className="absolute top-[80%] left-[20%] w-[80%] h-[90px] bg-gradient-to-r from-emerald-300/35 via-white/10 to-transparent rounded-full blur-xl -rotate-3" />
          </div>

          {/* High-End Photographic / Rendered Bus Composite */}
          <div className="relative rounded-2xl overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.8)] border border-emerald-500/30">
            <img
              src={ASSETS.heroBus}
              alt="Pakistan Express Khalid Nasir Luxury Touring Bus"
              referrerPolicy="no-referrer"
              className="w-full h-auto object-cover max-h-[380px] filter contrast-110 brightness-105"
            />

            {/* Glowing Digital Destination Board Overlay on Bus */}
            <div className="absolute top-[18%] left-[24%] px-3 py-1 bg-black/90 border border-emerald-400/70 rounded shadow-[0_0_15px_#10b981] hidden sm:flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-[11px] font-bold tracking-[0.2em] text-emerald-300 font-mono-tech uppercase">
                PAKISTAN EXPRESS • VIP EXECUTIVE
              </span>
            </div>

            {/* Rear Crimson LED Taillight Trails */}
            <div className="absolute top-[60%] left-0 w-16 h-8 bg-red-600/60 blur-lg rounded-l-full" />
            <div className="absolute top-[62%] -left-12 w-28 h-2 bg-gradient-to-l from-red-500/80 to-transparent blur-sm" />
          </div>

          {/* Bus Shadow & Wet Reflection on Highway */}
          <div className="w-full h-12 bg-black/90 rounded-full blur-xl transform scale-y-40 -mt-3" />
        </motion.div>
      </div>

      {/* Floating Canvas Particle Layer */}
      <canvas ref={canvasRef} className="absolute inset-0 z-20 pointer-events-none" />
    </div>
  );
};
