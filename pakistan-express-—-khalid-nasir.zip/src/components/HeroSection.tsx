import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Calendar, MapPin, Users, Sparkles, Navigation, ShieldCheck, Zap, Compass, ChevronRight } from 'lucide-react';
import { CinematicBusHighway } from './CinematicBusHighway';
import { CITIES } from '../data/mockData';

interface HeroSectionProps {
  onOpenBookingWithParams: (params: { from: string; to: string; date: string; passengers: number }) => void;
  onExploreRoutes: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onOpenBookingWithParams,
  onExploreRoutes,
}) => {
  const [fromCity, setFromCity] = useState('Karachi');
  const [toCity, setToCity] = useState('Rawalpindi');
  const [travelDate, setTravelDate] = useState('Today, Aug 18');
  const [passengerCount, setPassengerCount] = useState(1);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onOpenBookingWithParams({
      from: fromCity,
      to: toCity,
      date: travelDate,
      passengers: passengerCount,
    });
  };

  const routeStops = ['Karachi', 'Hyderabad', 'Sukkur', 'Multan', 'Rawalpindi'];

  return (
    <section id="hero" className="relative min-h-screen w-full flex flex-col justify-between pt-24 pb-12 overflow-hidden bg-[#050505] text-white">
      {/* Background Cinematic Bus & Highway Canvas Engine */}
      <CinematicBusHighway />

      {/* Atmospheric Lighting & Radial Gradients (Immersive UI) */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,#0a2f1c_0%,#050505_70%)] opacity-85 pointer-events-none -z-10" />
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-emerald-600/20 rounded-full blur-[120px] pointer-events-none -z-10" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-emerald-500/10 rounded-full blur-[140px] pointer-events-none -z-10" />

      {/* Sleek Highway Grid Overlay / Ambient Speedlines */}
      <div className="absolute inset-0 immersive-grid-pattern pointer-events-none -z-10" />

      {/* Speed lines & Horizon Accent */}
      <div className="absolute bottom-28 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-emerald-500/40 to-transparent pointer-events-none" />
      <div className="absolute bottom-20 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_15px_#10b981] pointer-events-none" />

      {/* Main Content Container */}
      <div className="relative z-30 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full flex flex-col justify-center flex-grow">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center py-6 sm:py-10">
          
          {/* Left Column: Cinematic Headline & Brand Typography */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            {/* VIP Status Chip */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono-tech tracking-widest uppercase backdrop-blur-md mb-4 shadow-[0_0_20px_rgba(16,185,129,0.25)]"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Royal Class Intercity Transit</span>
            </motion.div>

            {/* Main Brand Title: PAKISTAN EXPRESS */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            >
              <h1 className="text-3xl sm:text-5xl md:text-6xl font-black tracking-widest text-white uppercase font-heading leading-tight">
                Pakistan <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-emerald-300 to-white">Express</span>
              </h1>
            </motion.div>

            {/* Sub-brand: KHALID NASIR */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.7, delay: 0.25 }}
              className="mt-2 flex items-center gap-3"
            >
              <div className="h-[1px] w-8 sm:w-12 bg-emerald-500" />
              <span className="text-xs sm:text-sm md:text-base font-bold tracking-[0.4em] uppercase text-emerald-400 emerald-glow-text font-mono-tech">
                Khalid Nasir
              </span>
              <div className="h-[1px] w-8 sm:w-12 bg-emerald-500" />
            </motion.div>

            {/* Main Tagline */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="mt-6"
            >
              <h2 className="text-4xl sm:text-6xl md:text-7xl lg:text-7xl font-black tracking-tighter uppercase leading-[0.9] text-white">
                Your Journey.<br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-emerald-200 to-white drop-shadow-[0_0_35px_rgba(16,185,129,0.4)]">
                  Our Responsibility.
                </span>
              </h2>
            </motion.div>

            {/* Supportive description */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.55 }}
              className="mt-5 text-emerald-100/70 text-sm sm:text-base max-w-xl font-light tracking-wide leading-relaxed"
            >
              Redefining intercity luxury travel across Pakistan with zero-gravity seating, private executive cabins, Starlink connectivity, and high-speed motorway radar precision.
            </motion.p>

            {/* Hero CTA Buttons (Immersive UI geometry) */}
            <motion.div
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.7 }}
              className="mt-8 flex flex-wrap items-center gap-4"
            >
              {/* Primary Book Your Seat Button */}
              <button
                onClick={() => onOpenBookingWithParams({ from: fromCity, to: toCity, date: travelDate, passengers: passengerCount })}
                id="hero-book-seat-cta"
                className="group relative px-8 py-4 bg-emerald-500 text-black font-black uppercase tracking-widest text-xs rounded-sm overflow-hidden hover:bg-emerald-400 transition-all shadow-[0_0_30px_rgba(16,185,129,0.5)] hover:shadow-[0_0_45px_rgba(16,185,129,0.8)] hover:scale-105 flex items-center gap-3"
              >
                <span className="relative z-10 text-black flex items-center gap-2">
                  Reserve Seat
                  <ArrowRight className="w-4 h-4 text-black group-hover:translate-x-1 transition-transform" />
                </span>
                {/* Shine Sweep Effect */}
                <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/50 to-transparent skew-x-12" />
              </button>

              {/* Secondary Explore Routes Button */}
              <button
                onClick={onExploreRoutes}
                id="hero-explore-routes-cta"
                className="px-7 py-4 border border-white/20 text-white font-bold uppercase tracking-widest text-xs rounded-sm hover:border-emerald-400 hover:text-emerald-400 transition-all backdrop-blur-md bg-white/5 flex items-center gap-2 group hover:-translate-y-0.5"
              >
                <Compass className="w-4 h-4 text-emerald-400 group-hover:rotate-45 transition-transform duration-300" />
                <span>Explore Fleet & Routes</span>
              </button>
            </motion.div>
          </div>

          {/* Right Column: Floating Luxury Booking Interface */}
          <div className="lg:col-span-5 relative mt-6 lg:mt-0">
            
            {/* Animated Route Line Indicator Behind/Above Card */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.6 }}
              className="mb-3 px-4 py-2 rounded-xl bg-black/80 backdrop-blur-md border border-emerald-500/30 flex items-center justify-between text-[11px] font-mono-tech text-gray-300 shadow-lg"
            >
              <div className="flex items-center gap-1.5 text-emerald-400">
                <Zap className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                <span className="font-bold tracking-wider">M-9 & M-5 CORRIDOR</span>
              </div>
              <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
                {routeStops.map((stop, index) => (
                  <React.Fragment key={stop}>
                    <span className={index === 0 || index === routeStops.length - 1 ? 'text-white font-bold' : 'text-gray-400'}>
                      {stop}
                    </span>
                    {index < routeStops.length - 1 && (
                      <ChevronRight className="w-3 h-3 text-emerald-400 shrink-0" />
                    )}
                  </React.Fragment>
                ))}
              </div>
            </motion.div>

            {/* The Floating Booking Card */}
            <motion.div
              animate={{ y: [0, -6, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
              className="bg-white/5 backdrop-blur-2xl border border-white/10 p-6 sm:p-8 rounded-2xl shadow-[0_25px_60px_rgba(0,0,0,0.8)] relative"
              id="hero-floating-booking-card"
            >
              {/* Header */}
              <div className="flex items-center justify-between pb-4 border-b border-white/10">
                <div>
                  <h3 className="text-lg font-black text-white tracking-wider uppercase font-heading">
                    Instant Seat Booking
                  </h3>
                  <p className="text-[11px] text-emerald-400/80 font-mono-tech mt-0.5">
                    Live seat inventory & instant confirmation
                  </p>
                </div>
                <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                  <Navigation className="w-5 h-5" />
                </div>
              </div>

              {/* Booking Form Fields */}
              <form onSubmit={handleSearch} className="mt-5 space-y-3.5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  
                  {/* FROM */}
                  <div className="p-3.5 rounded-xl bg-black/50 border border-white/5 hover:border-emerald-500/40 transition-colors">
                    <label className="block text-[10px] font-mono-tech font-bold uppercase tracking-widest text-emerald-400">
                      DEPARTURE
                    </label>
                    <div className="mt-1 flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-emerald-400 shrink-0" />
                      <select
                        value={fromCity}
                        onChange={(e) => setFromCity(e.target.value)}
                        className="w-full bg-transparent text-white font-semibold text-sm focus:outline-none cursor-pointer"
                      >
                        {CITIES.map((city) => (
                          <option key={city} value={city} className="bg-neutral-900 text-white">
                            {city}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* TO */}
                  <div className="p-3.5 rounded-xl bg-black/50 border border-white/5 hover:border-emerald-500/40 transition-colors">
                    <label className="block text-[10px] font-mono-tech font-bold uppercase tracking-widest text-emerald-400">
                      DESTINATION
                    </label>
                    <div className="mt-1 flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-emerald-400 shrink-0" />
                      <select
                        value={toCity}
                        onChange={(e) => setToCity(e.target.value)}
                        className="w-full bg-transparent text-white font-semibold text-sm focus:outline-none cursor-pointer"
                      >
                        {CITIES.filter((c) => c !== fromCity).map((city) => (
                          <option key={city} value={city} className="bg-neutral-900 text-white">
                            {city}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* DATE */}
                  <div className="p-3.5 rounded-xl bg-black/50 border border-white/5 hover:border-emerald-500/40 transition-colors">
                    <label className="block text-[10px] font-mono-tech font-bold uppercase tracking-widest text-emerald-400">
                      TRAVEL DATE
                    </label>
                    <div className="mt-1 flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-emerald-400 shrink-0" />
                      <select
                        value={travelDate}
                        onChange={(e) => setTravelDate(e.target.value)}
                        className="w-full bg-transparent text-white font-semibold text-sm focus:outline-none cursor-pointer"
                      >
                        <option value="Today, Aug 18" className="bg-neutral-900 text-white">Today, Aug 18</option>
                        <option value="Tomorrow, Aug 19" className="bg-neutral-900 text-white">Tomorrow, Aug 19</option>
                        <option value="Wednesday, Aug 20" className="bg-neutral-900 text-white">Wednesday, Aug 20</option>
                        <option value="Thursday, Aug 21" className="bg-neutral-900 text-white">Thursday, Aug 21</option>
                        <option value="Friday, Aug 22" className="bg-neutral-900 text-white">Friday, Aug 22</option>
                      </select>
                    </div>
                  </div>

                  {/* PASSENGERS */}
                  <div className="p-3.5 rounded-xl bg-black/50 border border-white/5 hover:border-emerald-500/40 transition-colors">
                    <label className="block text-[10px] font-mono-tech font-bold uppercase tracking-widest text-emerald-400">
                      PASSENGERS
                    </label>
                    <div className="mt-1 flex items-center gap-2">
                      <Users className="w-4 h-4 text-emerald-400 shrink-0" />
                      <select
                        value={passengerCount}
                        onChange={(e) => setPassengerCount(Number(e.target.value))}
                        className="w-full bg-transparent text-white font-semibold text-sm focus:outline-none cursor-pointer"
                      >
                        <option value={1} className="bg-neutral-900 text-white">1 Passenger</option>
                        <option value={2} className="bg-neutral-900 text-white">2 Passengers</option>
                        <option value={3} className="bg-neutral-900 text-white">3 Passengers</option>
                        <option value={4} className="bg-neutral-900 text-white">4 Passengers</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* SEARCH BUSES BUTTON */}
                <button
                  type="submit"
                  id="search-buses-card-btn"
                  className="w-full mt-2 py-4 px-6 rounded-sm bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs uppercase tracking-widest shadow-[0_0_25px_rgba(16,185,129,0.5)] hover:shadow-[0_0_35px_rgba(16,185,129,0.8)] active:scale-[0.98] transition-all duration-200 flex items-center justify-center gap-3 group"
                >
                  <span>SEARCH AVAILABLE COACHES</span>
                  <ArrowRight className="w-4 h-4 text-black group-hover:translate-x-1 transition-transform" />
                </button>
              </form>

              {/* Card Trust Badges */}
              <div className="mt-4 pt-3.5 border-t border-white/5 flex items-center justify-between text-[11px] text-gray-400 font-mono-tech">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Guaranteed Seat
                </span>
                <span className="text-emerald-400 font-medium">
                  Direct Khalid Nasir Terminal
                </span>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Bottom Telemetry & Status Bar (Immersive UI signature) */}
        <div className="relative z-10 grid grid-cols-2 lg:grid-cols-4 gap-4 w-full pt-6 pb-2 border-t border-white/10 mt-6">
          <div className="flex flex-col">
            <span className="text-[10px] uppercase font-mono-tech tracking-widest text-emerald-400/80">Network Fleet</span>
            <span className="text-base sm:text-lg font-bold tracking-tight text-white mt-0.5">Scania Touring HD</span>
          </div>
          <div className="flex flex-col border-l border-white/10 pl-4">
            <span className="text-[10px] uppercase font-mono-tech tracking-widest text-emerald-400/80">Safety Rating</span>
            <span className="text-base sm:text-lg font-bold tracking-tight text-white mt-0.5">99.8% Punctual</span>
          </div>
          <div className="flex flex-col border-l border-white/10 pl-4">
            <span className="text-[10px] uppercase font-mono-tech tracking-widest text-emerald-400/80">Motorway Speed</span>
            <span className="text-base sm:text-lg font-bold tracking-tight text-white mt-0.5">120 KM/H Radar</span>
          </div>
          <div className="flex flex-col border-l border-white/10 pl-4 items-start lg:items-end justify-center">
            <div className="flex items-center gap-2 text-xs font-mono-tech text-emerald-400 font-semibold tracking-wider">
              <span className="w-2 h-2 bg-emerald-400 rounded-full animate-ping" />
              SYSTEM OPERATIONAL
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
