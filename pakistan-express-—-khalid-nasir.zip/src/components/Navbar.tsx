import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bus, MapPin, Search, PhoneCall, Moon, Sun, Menu, X, ArrowRight, ShieldCheck, Ticket } from 'lucide-react';

interface NavbarProps {
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  onOpenBooking: () => void;
  onOpenTrack: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  darkMode,
  setDarkMode,
  onOpenBooking,
  onOpenTrack,
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#hero' },
    { name: 'Routes', href: '#routes' },
    { name: 'Network Map', href: '#network-map' },
    { name: 'VIP Fleet', href: '#fleet' },
    { name: 'Live Status', href: '#live-status' },
    { name: 'Experience', href: '#experience' },
  ];

  const handleScrollTo = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <header
        id="main-navbar"
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          scrolled
            ? 'py-3 bg-black/80 dark:bg-[#040806]/85 backdrop-blur-xl border-b border-emerald-500/20 shadow-[0_10px_30px_rgba(0,0,0,0.5)]'
            : 'py-5 bg-gradient-to-b from-black/80 via-black/40 to-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Brand Logo */}
          <a
            href="#hero"
            onClick={(e) => handleScrollTo(e, '#hero')}
            className="flex items-center gap-3.5 group"
            id="brand-logo-btn"
          >
            <div className="relative">
              <div className="w-10 h-10 bg-emerald-500 rounded-sm flex items-center justify-center rotate-45 border border-emerald-300 shadow-[0_0_15px_rgba(16,185,129,0.5)] group-hover:scale-105 transition-transform duration-300">
                <Bus className="w-5 h-5 text-black font-black -rotate-45" />
              </div>
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full animate-ping opacity-75" />
            </div>

            <div className="flex flex-col">
              <span className="text-base sm:text-lg font-black tracking-widest text-white uppercase font-heading">
                Pakistan <span className="text-emerald-400">Express</span>
              </span>
              <span className="text-[10px] tracking-[0.3em] uppercase text-emerald-400 font-mono-tech -mt-0.5">
                Khalid Nasir
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2 px-4 py-1.5 rounded-full bg-black/50 backdrop-blur-md border border-white/10">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleScrollTo(e, link.href)}
                className="px-3.5 py-1.5 text-xs font-semibold tracking-wider uppercase text-gray-300 hover:text-emerald-400 hover:bg-white/5 rounded-full transition-all duration-200"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Desktop Actions */}
          <div className="hidden sm:flex items-center gap-3">
            {/* Track Booking Button */}
            <button
              onClick={onOpenTrack}
              id="nav-track-btn"
              className="px-4 py-2 text-xs font-bold tracking-widest uppercase text-gray-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 hover:border-emerald-500/40 rounded-sm flex items-center gap-2 transition-all duration-200"
            >
              <Ticket className="w-3.5 h-3.5 text-emerald-400" />
              <span>Track PNR</span>
            </button>

            {/* Dark / Light Mode Toggle */}
            <button
              onClick={() => setDarkMode(!darkMode)}
              id="theme-toggle-btn"
              aria-label="Toggle theme"
              className="p-2.5 rounded-sm bg-white/5 hover:bg-white/10 text-gray-300 hover:text-emerald-400 border border-white/10 transition-colors"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Main Booking CTA */}
            <button
              onClick={onOpenBooking}
              id="nav-book-now-btn"
              className="relative group overflow-hidden px-6 py-2.5 rounded-sm bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs uppercase tracking-widest shadow-[0_0_25px_rgba(16,185,129,0.5)] hover:shadow-[0_0_35px_rgba(16,185,129,0.8)] hover:scale-105 transition-all duration-300 flex items-center gap-2"
            >
              <span className="relative z-10 font-black text-black">Reserve Seat</span>
              <ArrowRight className="w-3.5 h-3.5 text-black group-hover:translate-x-1 transition-transform relative z-10" />
              {/* Button Shine sweep */}
              <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/40 to-transparent skew-x-12" />
            </button>
          </div>

          {/* Mobile Hamburger Button */}
          <div className="flex sm:hidden items-center gap-2">
            <button
              onClick={() => setDarkMode(!darkMode)}
              aria-label="Toggle theme"
              className="p-2 rounded-lg bg-white/5 text-gray-300 border border-white/10"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              id="mobile-menu-toggle-btn"
              className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Slide-down Drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-x-0 top-[65px] z-30 bg-[#050806]/95 backdrop-blur-2xl border-b border-emerald-500/30 p-6 flex flex-col gap-4 shadow-2xl lg:hidden"
          >
            <div className="flex flex-col gap-2">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={(e) => handleScrollTo(e, link.href)}
                  className="px-4 py-3 text-sm font-semibold tracking-wider uppercase text-gray-200 hover:text-emerald-400 hover:bg-emerald-950/40 rounded-xl transition-colors"
                >
                  {link.name}
                </a>
              ))}
            </div>

            <div className="pt-4 border-t border-emerald-950/60 flex flex-col gap-3">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenTrack();
                }}
                className="w-full py-3 px-4 rounded-xl bg-white/5 border border-white/10 text-white text-xs uppercase tracking-wider font-semibold flex items-center justify-center gap-2"
              >
                <Ticket className="w-4 h-4 text-emerald-400" />
                Track Ticket PNR
              </button>

              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenBooking();
                }}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-400 text-black font-extrabold text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(16,185,129,0.5)] flex items-center justify-center gap-2"
              >
                Book Your Seat
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
