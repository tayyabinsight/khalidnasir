import React from 'react';
import { motion } from 'motion/react';
import { Star, Sparkles, Quote, MapPin, CheckCircle2 } from 'lucide-react';
import { TESTIMONIALS } from '../data/mockData';

export const TestimonialsSection: React.FC = () => {
  return (
    <section id="testimonials" className="relative py-24 bg-[#030604] text-white overflow-hidden border-t border-emerald-950/40">
      {/* Background radial glow */}
      <div className="absolute top-1/2 left-1/3 w-[50vw] h-[50vh] bg-emerald-950/15 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-950/70 border border-emerald-500/30 text-emerald-400 text-xs font-mono-tech uppercase tracking-widest mb-4"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>COMMUNITY OF TRAVELERS</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white uppercase font-heading"
          >
            Voices from <br className="sm:hidden" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-emerald-300 to-white">
              The Highway
            </span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="mt-4 text-sm sm:text-base text-gray-300"
          >
            Real feedback from business leaders, researchers, and families who rely on Khalid Nasir’s Pakistan Express.
          </motion.p>
        </div>

        {/* Animated Horizontal Testimonial Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t, idx) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.15, duration: 0.6 }}
              className="glass-panel-glow rounded-3xl p-6 sm:p-8 border border-emerald-500/30 relative flex flex-col justify-between group hover:border-emerald-400 transition-all duration-300 shadow-xl"
            >
              <div>
                {/* Rating & Route Header */}
                <div className="flex items-center justify-between pb-4 border-b border-emerald-950/70">
                  <div className="flex items-center gap-1 text-emerald-400">
                    {Array.from({ length: t.rating }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-emerald-400 text-emerald-400" />
                    ))}
                  </div>

                  <span className="text-[10px] font-mono-tech text-gray-400 bg-black/50 px-2.5 py-1 rounded-full border border-white/5">
                    {t.date}
                  </span>
                </div>

                {/* Route Pill */}
                <div className="mt-4 inline-flex items-center gap-1.5 text-xs text-emerald-300 font-medium">
                  <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{t.route}</span>
                </div>

                {/* Quote */}
                <p className="mt-4 text-sm text-gray-200 leading-relaxed italic">
                  "{t.quote}"
                </p>
              </div>

              {/* Passenger Bio Footer */}
              <div className="mt-6 pt-5 border-t border-emerald-950/70 flex items-center gap-3">
                <img
                  src={t.avatar}
                  alt={t.name}
                  referrerPolicy="no-referrer"
                  className="w-11 h-11 rounded-full object-cover border border-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.4)]"
                />
                <div>
                  <div className="text-sm font-bold text-white flex items-center gap-1">
                    <span>{t.name}</span>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                  <div className="text-xs text-gray-400">
                    {t.role} • {t.city}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Placeholder disclaimer */}
        <div className="mt-12 text-center text-xs text-gray-500 font-mono-tech">
          * Representative customer testimonials for Pakistan Express landing page demonstration.
        </div>

      </div>
    </section>
  );
};
